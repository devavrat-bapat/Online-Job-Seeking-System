package dao;

public class EditJobPost {

	public void getJobPost(){
		
		
	}
}
