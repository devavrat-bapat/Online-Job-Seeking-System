package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class ManageApplicant {

	
	public static char registerApplicantDev(String EmailId, String Password, String FirstName, String LastName, String Phone,
			String Location, String Summary, String employmentStatus, LocalDate dateOfBirth,String Gender, 
			String University, String Major, LocalDate MajorStartDate, LocalDate MajorEndDate, String GPA,
			String EmployerName, String Designation, LocalDate ExperienceStartDate, LocalDate ExperienceEndDate, String JobLocation,
			String JobDescription) {

		char flag = 'a';
			
		try {
			Connection con =Connector.connect1();
			System.out.println("inside redDev");
			flag = 0;
			
			//Check Email exists in database or not
			
			Statement stm = con.createStatement();
			System.out.println("select * from users where username ='"+EmailId+"'");
			ResultSet rs =stm.executeQuery("select * from users where username ='"+EmailId+"'");
			
			if(rs.next()){
				flag ='e';
				return flag;
			}
			else{
			//Users
			
			Statement statement = con.createStatement();
			System.out.println("insert into users(role, username, password) values('applicant','" + EmailId + "','" + Password + "')");
			statement.executeUpdate("insert into users(role, username, password) "
									+ "values('applicant','" + EmailId + "','" + Password + "')");
			
			
			//
			Statement statement1 = con.createStatement();
			
			System.out.println(
					"insert into applicant_profile(user_id,first_name,last_name,phone_no,location,summary,resume,employment_status,dateOfBirth,profile_picture,"
							+ "gender,email_id) values((select user_id from users where username='"+EmailId+"'),'"+FirstName+"','"+LastName+"',"+Phone
									+",'"+Location+"','"+Summary+"','resume','"+employmentStatus+"','"+dateOfBirth+"','profpic','"+Gender+"','"+EmailId+"')");
			statement1.executeUpdate(
					"insert into applicant_profile(user_id,first_name,last_name,phone_no,location,summary,resume,employment_status,dateOfBirth,profile_picture,"
					+ "gender,email_id) values((select user_id from users where username='"+EmailId+"'),'"+FirstName+"','"+LastName+"',"+Phone
							+",'"+Location+"','"+Summary+"','resume','"+employmentStatus+"','"+dateOfBirth+"','profpic','"+Gender+"','"+EmailId+"')");
							
			//
			Statement statement2 = con.createStatement();
			
			System.out.println("insert into applicant_education(user_id,major,university,start_date,end_date,gpa,cert_degree)"
									+ "values((select user_id from users where username='"+ EmailId + "'),'"
									+ Major + "','" + University + "','" + MajorStartDate + "','" + MajorEndDate + "'," + GPA + ",'cert_deg')");
			statement2.executeUpdate("insert into applicant_education(user_id,major,university,start_date,end_date,gpa,cert_degree)"
									+ "values((select user_id from users where username='"+ EmailId + "'),'"
									+ Major + "','" + University + "','" + MajorStartDate + "','" + MajorEndDate + "'," + GPA + ",'cert_deg')");
			
			//
			if(!EmployerName.equals(null))
			{		
			Statement statement3 = con.createStatement();
			System.out.println("insert into applicant_experience_details(user_id,employer_name,designation,start_date,end_date,location,description)"
									+ "values((select user_id from users where username='"+EmailId+"'),'"+EmployerName+"','"+Designation+
											"','"+ExperienceStartDate+"','"+ExperienceEndDate+"','"+JobLocation+"','"+JobDescription+"')");
			statement3.executeUpdate("insert into applicant_experience_details(user_id,employer_name,designation,start_date,end_date,location,description)"
									+ "values((select user_id from users where username='"+EmailId+"'),'"+EmployerName+"','"+Designation+"','"
											+ExperienceStartDate+"','"+ExperienceEndDate+"','"+JobLocation+"','"+JobDescription+"')");
			}
			flag='s';
			}
		} catch (SQLException e) {
			flag = 'f';
			e.printStackTrace();
		}
		return flag;
	}

	
	public static ResultSet getApplicant() throws SQLException{
		
		Connection con = Connector.connect1();
		Statement stm = con.createStatement();
		return stm.executeQuery("select * from applicant_profile");
		
	}
}