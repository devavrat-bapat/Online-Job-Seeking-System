package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;


public class ApplyForJob {

	public static int apply(int user_id, int job_id){
		
		int flag =0;
		Date dt = new Date();

		java.text.SimpleDateFormat sdf = 
		     new java.text.SimpleDateFormat("yyyy-MM-dd");

		String currentTime = sdf.format(dt);
		try {
		Connection con = Connector.connect1();
		Statement stm = con.createStatement();
		
			stm.executeUpdate("insert into application_history(user_id,job_id,apply_date) values("+user_id+","+job_id+",'"+currentTime+"')");
		} catch (SQLException e) {
			flag =1;
			e.printStackTrace();
		}
		return flag;
	}
	
}
