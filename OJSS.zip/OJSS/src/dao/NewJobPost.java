package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;


public class NewJobPost {

	public static char addJobPost(int user_id, Object value, String text, String text2, String text3,
			String currentTime, LocalDate localDate) throws SQLException {
		
		char a='d';
		try{
		Connection con = Connector.connect1();
		Statement stm = con.createStatement();
		ResultSet rs;
		System.out.println("");
		System.out.println("insert into job_post(user_id,job_type, job_designation, job_description, job_location, job_created_date, job_expiry_date) "
				+ "values("+user_id+",'"+value+"','"+text+"','"+text2+"','"+text3+"','"+currentTime+"','"+localDate+"')");
		stm.executeUpdate("insert into job_post(user_id,job_type, job_designation, job_description, job_location, job_created_date, job_expiry_date) "
				+ "values("+user_id+",'"+value+"','"+text+"','"+text2+"','"+text3+"','"+currentTime+"','"+localDate+"')");
		a='s';
		System.out.println("Job post created");
		}
		catch(Exception e)
		{
			a='f';
		}
		return a;
	}

	public static char updateJobPost(int user_id, int tempJobId, Object job_type, String job_designation, String job_description, String job_location,
			String currentTime, LocalDate expiryDate) {
	
		char a='d';
		try{
		Connection con = Connector.connect1();
		Statement stm = con.createStatement();
		ResultSet rs;
		System.out.println("update job_post SET job_type='"+job_type+"', job_designation='"+job_designation+"', job_description='"
							+job_description+"', job_location='"+job_location+"', "
							+ "job_created_date='"+currentTime+"', job_expiry_date='"+expiryDate+"' WHERE job_id="+tempJobId);
		
		stm.executeUpdate("update job_post SET job_type='"+job_type+"', job_designation='"+job_designation+"', job_description='"+job_description+"', job_location='"+job_location+"', "
				+ "job_created_date='"+currentTime+"', job_expiry_date='"+expiryDate+"' WHERE job_id="+tempJobId);
		
	/*	System.out.println("update table job_post(job_id,user_id,job_type, job_designation, job_description, job_location, job_created_date, job_expiry_date) "
				+ "values("+user_id+",'"+tempJobId+"','"+job_type+"','"+job_designation+"','"+job_description+"','"+job_location+"','"+currentTime+"','"+expiryDate+"'))");
		stm.executeUpdate("update table job_post(job_id,user_id,job_type, job_designation, job_description, job_location, job_created_date, job_expiry_date) "
				+ "values('"+tempJobId+"',"+user_id+",'"+job_type+"','"+job_designation+"','"+job_description+"','"+job_location+"','"+currentTime+"','"+expiryDate+"'))");
	*/	a='s';
		System.out.println("Job post created");
		}
		catch(Exception e)
		{
			a='f';
		}
		return a;
	}
	
	public static char updateAdminJobPost(int tempJobId, Object job_type, String job_designation, String job_description, String job_location,
			String currentTime, LocalDate expiryDate) {
	
		char a='d';
		try{
		Connection con = Connector.connect1();
		Statement stm = con.createStatement();
		ResultSet rs;
		System.out.println("update job_post SET job_type='"+job_type+"', job_designation='"+job_designation+"', job_description='"
							+job_description+"', job_location='"+job_location+"', "
							+ "job_created_date='"+currentTime+"', job_expiry_date='"+expiryDate+"' WHERE job_id="+tempJobId);
		
		stm.executeUpdate("update job_post SET job_type='"+job_type+"', job_designation='"+job_designation+"', job_description='"+job_description+"', job_location='"+job_location+"', "
				+ "job_created_date='"+currentTime+"', job_expiry_date='"+expiryDate+"' WHERE job_id="+tempJobId);
		
	/*	System.out.println("update table job_post(job_id,user_id,job_type, job_designation, job_description, job_location, job_created_date, job_expiry_date) "
				+ "values("+user_id+",'"+tempJobId+"','"+job_type+"','"+job_designation+"','"+job_description+"','"+job_location+"','"+currentTime+"','"+expiryDate+"'))");
		stm.executeUpdate("update table job_post(job_id,user_id,job_type, job_designation, job_description, job_location, job_created_date, job_expiry_date) "
				+ "values('"+tempJobId+"',"+user_id+",'"+job_type+"','"+job_designation+"','"+job_description+"','"+job_location+"','"+currentTime+"','"+expiryDate+"'))");
	*/	a='s';
		System.out.println("Job post created");
		}
		catch(Exception e)
		{
			a='f';
		}
		return a;
	}
}
