package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class ManageEmployer {

	public static char updateAdminEmployer(int empId, String CompanyName, String IndustryType, String EmailId, String phone_no, String Location,  LocalDate establishment_date) {
		
		char a='f';
			
		try {
			Connection con = Connector.connect1();
			Statement stm = con.createStatement();
			System.out.println("update employer_profile SET company_name='"+CompanyName+"',email_id='"+EmailId+"',industry_type='"+IndustryType+"',"
					+ "location= '"+Location+"', phone_number ="+phone_no+" where user_id="+empId);
			stm.executeUpdate("update employer_profile SET company_name='"+CompanyName+"',email_id='"+EmailId+"',industry_type='"+IndustryType+"',"
					+ "location= '"+Location+"', phone_number ="+phone_no+" where user_id="+empId);
			
				a='s';
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			return a;
		}

	public static char deleteEmployer(int empId) {
		char flag='f';
		Connection con = Connector.connect1();
		try {
			Statement stm = con.createStatement();
			stm.executeUpdate("delete from employer_profile where user_id="+empId);
		} catch (SQLException e) {
			
			e.printStackTrace();
			flag ='f';
		} catch(Exception e)
		{
			flag ='f';
		}
		return flag;
	}
		
	

		public static char updateProfile(String CompanyName, String EmailId, String IndustryType, String Location, String CompanyURL,
				String Description, LocalDate establishment_date, String Phone, String Password, String ConfirmPassword){
		char a='f';
			
		try {
			Connection con = Connector.connect1();
			Statement stm = con.createStatement();
			System.out.println("update employer_profile SET company_name='"+CompanyName+"',email_id='"+EmailId+"',industry_type='"+IndustryType+"',"
					+ "location= '"+Location+"', company_url ='"+CompanyURL+"', phone_number ="+Phone+"', description'"+Description+"'");
			stm.executeUpdate("update employer_profile SET company_name='"+CompanyName+"',email_id='"+EmailId+"',industry_type='"+IndustryType+"',"
					+ "location= '"+Location+"', company_url ='"+CompanyURL+"', phone_number ="+Phone+", description='"+Description+"'");
			Statement stm1 = con.createStatement();
			System.out.println("update users SET password='"+Password+"' WHERE username='"+EmailId+"'");
			
			
				stm1.executeUpdate("update users SET password='"+Password+"' WHERE username='"+EmailId+"'");
				a='s';
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			return a;
		}

}
