package dao;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import model.Applicant;
	import model.Employer;
	import model.User;


	public class Connector {
	
	char checkStatus;
	static Connection con;
	static ResultSet rs;
	static int userID;
	
	//method to return Connector object
	
	public static void connect(){
		
		try {
		Class.forName("com.mysql.jdbc.Driver");
		
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/job_seeking_system", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}
public static Connection connect1(){
		
		try {
		Class.forName("com.mysql.jdbc.Driver");
		
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/job_seeking_system", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		return con;
	}

	public static User validateLogin(User u1){
		connect();
	
	try {

	// establish connection
	
	Statement statement = con.createStatement();
	rs = statement.executeQuery("select user_id,role from users where username='"+u1.username+"' AND password='"+u1.password+"'");
	
	
	
	if(rs.next()){
		u1.role = rs.getString("role");
		u1.userID = rs.getInt("user_id");
	}
	else
		u1.role = "invalid";
	
	
	}catch (SQLException e) {
	e.printStackTrace();
	}
		//disconnect();
		return u1;
	
	}
	
	
	
	
	/*
	 * 
	 * 
	 * Get the applicant profile
	 */
	
	public static Applicant getApplicant(Applicant a1) throws SQLException{
		
		Statement statement1 = con.createStatement();
	
		System.out.println("in getApplicant");
		System.out.println("app id = "+a1.user_id);
		System.out.println("1");
		ResultSet rs1 = statement1.executeQuery("select * from applicant_profile where user_id="+a1.user_id);
		Statement statement2 = con.createStatement();
		System.out.println("2");
		ResultSet rs2 = statement2.executeQuery("select * from applicant_education where user_id="+a1.user_id);
	
		System.out.println("3");
		Statement statement3 = con.createStatement();	
		ResultSet rs3 = statement3.executeQuery("select * from applicant_experience_details where user_id="+a1.user_id);

		a1.setApplicantProfile(rs1, rs2, rs3);
	
	//	disconnect();
		return a1;
		
	}
	
	

	/*
	 * 
	 * Insert entry in the users_log table
	 */
	public static void insertLog(int i,String currentTime){ 
		
		//a for admin, b for applicant, e for employer, i for incorrect credentials
	try {

	// establish connection

	Statement statement = con.createStatement();
	statement.executeUpdate("insert into users_log(user_id,last_login) values("+i+",'"+currentTime+"')");
		
	}catch (SQLException e) {

	// TODO Auto-generated catch block
	e.printStackTrace();
	}
		//disconnect();
}
	
	
	public static void getUserID() {
		
		connect();
		
	}
	public static Employer getEmployer(Employer e1) throws SQLException {
	
		Statement statement1 = con.createStatement();
		Statement statement2 = con.createStatement();
		
		
	
		ResultSet rs1 = statement1.executeQuery("select * from employer_profile where user_id="+e1.user_id);
		System.out.println("here1");
		ResultSet rs2 = statement2.executeQuery("select * from users where user_id="+e1.user_id);
		e1.setEmployerProfile(rs1,rs2);
	
	//	disconnect();
		return e1;
		
	}
	

	public static int registerEmployer(String text, String text2, String text3, String text4, String text5, String string, String text6, String text7, String text8) {
		int flag =0;
		System.out.println("inside reg Emp");
		System.out.println("insert into users(role, username, password) values('employer','"+text+"','"+text2+"')");
		System.out.println("insert into employer_profile values((select user_id from users where username='"+text+"'),'"+text3+"','"+text+"','"+text4+"','"+text5+"','"+string+"','"+text6+"','"+text7+"','"+text8+"',null)");
		
		try {
			connect();
			System.out.println("inside try blk");
		Statement statement = con.createStatement();
		statement.executeUpdate("insert into users(role, username, password) values('employer','"+text+"','"+text2+"')");
		
		Statement statement2 = con.createStatement();
		statement2.executeUpdate("insert into employer_profile values((select user_id from users where username='"+text+"'),'"+text3+"','"+text+"','"+text4+"','"+text5+"','"+string+"','"+text6+"','"+text7+"','"+text8+"',null)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	

	public static int registerEmployer1(String text, String text2, String text3) {
		int flag =0;
		System.out.println("inside reg Emp");
		System.out.println("insert into users(role, username, password) values('employer','"+text+"','"+text2+"')");
		System.out.println("insert into employer_profile values((select user_id from users where username='"+text+"'),'"+text3+"','"+text+"',null,null,null,null,null,null,null)");
		
		try {
			connect();
			System.out.println("inside try blk regEmp1");
		Statement statement10 = con.createStatement();
		System.out.println("executing query...");
		statement10.executeUpdate("insert into users(role, username, password) values('employer','"+text+"','"+text2+"');");
		
	//	Statement statement2 = con.createStatement();
	//	statement2.executeQuery("insert into employer_profile values((select user_id from users where username='"+text+"'),'"+text3+"','"+text+"','"+text4+"','"+text5+"','"+string+"','"+text6+"','"+text7+"','"+text8+"',null)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
/*	public static void disconnect(){
		
		try {
			rs.close();
			statement.close();
			con.close();
			
			} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
			}
	}*/
}// class Connector ends	


