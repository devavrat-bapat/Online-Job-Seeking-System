package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import dao.Connector;

public class ViewEmployer {

	

	

	public class JobPost{
		
		public int user_id;
		public int jobId;
		public String designation;
		public String jobDesctiption;
		public String yearsOfExperience;
		public String skills;
		public String jobType;
		public String salary;
		public int getUser_id() {
			return user_id;
		}
		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}
		public int getJobId() {
			return jobId;
		}
		public void setJobId(int jobId) {
			this.jobId = jobId;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getJobDesctiption() {
			return jobDesctiption;
		}
		public void setJobDesctiption(String jobDesctiption) {
			this.jobDesctiption = jobDesctiption;
		}
		public String getJobType() {
			return jobType;
		}
		public void setJobType(String jobType) {
			this.jobType = jobType;
		}
		public String getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getExpiredDate() {
			return expiredDate;
		}
		public void setExpiredDate(String expiredDate) {
			this.expiredDate = expiredDate;
		}
		public String getIsActive() {
			return isActive;
		}
		public void setIsActive(String isActive) {
			this.isActive = isActive;
		}

		public String createdDate;
		public String location;
		public String expiredDate;
		public String isActive;
		
		public JobPost(){}
		public JobPost(int jobId, int user_id, String jobType, String designation, String jobDesctiption, String location, String createdDate, String expiredDate,
				String isActive) {
			
			this.user_id = user_id;
			this.jobId = jobId;
			this.designation = designation;
			this.jobDesctiption = jobDesctiption;
			this.jobType = jobType;
			this.createdDate = createdDate;
			this.location = location;
			this.expiredDate = expiredDate;
			this.isActive = isActive;
			
			System.out.println("" +user_id+""+jobType+""+jobId+""+designation+""+jobDesctiption+""+location+""+createdDate+""+expiredDate+""+isActive);
		}
		
		public ResultSet getJobPost(){
			
		//	 Vector<Vector<Object>> jobPostData = new Vector<Vector<Object>>();
	 		// Vector<String> column = new Vector<String>();
	 		 
	 		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String reternJobPost = "select * from job_post";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 	//		setJobPost(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
	 			
	 			//pull data from your result set
	 		/*	 
	 			ResultSetMetaData metaData = rs.getMetaData();
	 			 
	 			int columns = metaData.getColumnCount();
	 		
	 			//get column names from table!
	 			String cols = null; 
	 			
	 			for (int i = 1; i <= columns; i++) {
	 				 cols = metaData.getColumnName(i);
	 				 column.add(cols);
	 			 }
	 			 //get row data from table!
	 		
	 			 while (rs.next()) {
	 				 Vector<Object> row = new Vector<Object>(columns);
	   	          
	 				 for (int i = 1; i <= columns; i++) {
	 					 row.addElement(rs.getObject(i));
	 					 
	 				 } 
	 				jobPostData.addElement(row);
	 			 }*/
	 			return rs;
	 		 } 
	 		 catch (SQLException e) {
	 			 // TODO Auto-generated catch block
	 			 e.printStackTrace();
	 		 } 
	 		 catch (Exception e) {
	 			 // TODO Auto-generated catch block
	 			 e.printStackTrace();
	 		 }
	 		 return null;
		}
	/*	private void setJobPost(int int1, int int2, String string, String string2, String string3, String string4,
				String string5, String string6, String string7) {
			this.user_id = int1;
			this.jobId = int2;
			this.designation = string;
			this.jobDesctiption = string2;
			this.jobType = string3;
			this.createdDate = string4;
			this.location = string5;
			this.expiredDate = string6;
			this.isActive = string7;
			
		}
		public void addJobPost(){}
		public void deleteJobPost(){}
		
		public void displayJobPost(){
		
			 
	 	   
			 
		
		
		}*/
		public ResultSet getJobPostFileter1(String f) {
			 try {
		 			
		 			Connection con = Connector.connect1();
		 			Statement stm = con.createStatement();
		 			String reternJobPost = "select * from job_post where job_type ='"+f+"'";
		 			ResultSet rs = stm.executeQuery(reternJobPost); 
		 			return rs;
	 		 } 
	 		 catch (SQLException e) {
	 			 // TODO Auto-generated catch block
	 			 e.printStackTrace();
	 		 } 
	 		 catch (Exception e) {
	 			 // TODO Auto-generated catch block
	 			 e.printStackTrace();
	 		 }
	 		 return null;
		
		}
		public ResultSet getJobPostFileter2(String f) {
			 try {
		 			
		 			Connection con = Connector.connect1();
		 			Statement stm = con.createStatement();
		 			String reternJobPost = "select * from job_post where job_type ='"+f+"'";
		 			ResultSet rs = stm.executeQuery(reternJobPost); 
		 			return rs;
			 } 
			 catch (SQLException e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 } 
			 catch (Exception e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 }
			 return null;
		
		}
		public ResultSet getJobPostFileter3(String f) {
			 try {
		 			
		 			Connection con = Connector.connect1();
		 			Statement stm = con.createStatement();
		 			String reternJobPost = "select * from job_post where job_created_date '"+f+"'";
		 			ResultSet rs = stm.executeQuery(reternJobPost); 
		 			return rs;
			 } 
			 catch (SQLException e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 } 
			 catch (Exception e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 }
			 return null;
		
		}
		public ResultSet getJobPostFileter4(String f) {
			 try {
		 			
		 			Connection con = Connector.connect1();
		 			Statement stm = con.createStatement();
		 			String reternJobPost = "select * from job_post where job_location ='"+f+"'";
		 			ResultSet rs = stm.executeQuery(reternJobPost); 
		 			return rs;
			 } 
			 catch (SQLException e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 } 
			 catch (Exception e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 }
			 return null;
		
		}
		
		public ResultSet applyManyFilters(String a,String b,String c,String d) {
			 try {
				 /*if(a==null){a="%%";}
				 if(b==null){b="%%";}
				 if(c==null){c="%%";}
				 if(d==null){d="%%";}
				 */
		 			Connection con = Connector.connect1();
		 			Statement stm = con.createStatement();
		 			System.out.println("select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"' AND job_created_date <'%%' AND job_location LIKE'"+d+"'");
		 			String reternJobPost = "select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"' AND job_location LIKE'"+d+"'";
		 			ResultSet rs = stm.executeQuery(reternJobPost); 
		 			/*if(rs.next())
		 			{
		 				System.out.println();
		 				System.out.println("1:"+rs.getObject(1)+"2:"+rs.getObject(2)+"3:"+rs.getObject(3)+"4:"+rs.getObject(4));
		 			}*/
		 			return rs;
		 			
		 			
			 } 
			 catch (SQLException e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 } 
			 catch (Exception e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			 }
			 return null;
		
		}
		
	}

	
}
