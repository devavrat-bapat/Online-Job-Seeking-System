package model;

public class User {

	public String username;
	public String password;
	public int userID;
	public String role;
	/*
	getUser(){
		
	}
	
	setUser(){
		
	}*/
}
