package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.jfoenix.controls.JFXButton;

import dao.Connector;
import javafx.scene.control.Button;

public class JobPost{
	
	public int user_id;
	public int jobId;
	public String company_name;
	public String designation;
	public String jobDesctiption;
	public String yearsOfExperience;
	public String skills;
	public String jobType;
	public String salary;
	public String createdDate;
	public String location;
	public String expiredDate;
	public String isActive;
	public JFXButton btn1;
	public String apply;
	public Button b1;
	
	public Button getB1() {
		return b1;
	}
	public void setB1(Button b1) {
		this.b1 = b1;
	}
	public String getApply() {
		return apply;
	}
	public void setApply(String apply) {
		this.apply = apply;
	}

	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getJobDesctiption() {
		return jobDesctiption;
	}
	public void setJobDesctiption(String jobDesctiption) {
		this.jobDesctiption = jobDesctiption;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(String expiredDate) {
		this.expiredDate = expiredDate;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	
	
	public JobPost(){}
	public JobPost(int jobId, String company_name, String jobType, String designation, String jobDesctiption, String location, String createdDate, String expiredDate) {
		
		this.company_name = company_name;
		this.jobId = jobId;
		this.designation = designation;
		this.jobDesctiption = jobDesctiption;
		this.jobType = jobType;
		this.createdDate = createdDate;
		this.location = location;
		this.expiredDate = expiredDate;
	//	this.isActive = isActive;
	/*	this.btn1 = new JFXButton("Apply");
		btn1.setStyle("-fx-background-color: #41E1C7");
		System.out.println("" +user_id+""+jobType+""+jobId+""+designation+""+jobDesctiption+""+location+""+createdDate+""+expiredDate+""+isActive);
	*/}
	
	public JFXButton getBtn1() {
		return btn1;
	}
	public void setBtn1(JFXButton btn1) {
		this.btn1 = btn1;
	}
	public ResultSet getJobPost(){
		
	//	 Vector<Vector<Object>> jobPostData = new Vector<Vector<Object>>();
 		// Vector<String> column = new Vector<String>();
 		 
 		 try {
 			
 			Connection con = Connector.connect1();
 			Statement stm = con.createStatement();
 			String returnJobPost = "select b.job_id,a.company_name, b.job_type,b.job_designation, b.job_description, b.job_location, b.job_created_date,"
 					+ " b.job_expiry_date from employer_profile a inner join job_post b where a.user_id=b.user_id";

 			ResultSet rs = stm.executeQuery(returnJobPost); 
 			System.out.println("Result set of Job");
 			if(rs.next())
 			{
 				System.out.println(""+rs.getInt(1)+""+rs.getString(2)+""+rs.getString(3)+""+rs.getString(4)+""+rs.getString(5)+""+rs.getString(6)+""+rs.getObject(7)+""+rs.getObject(8)+"");
 			}
 	//		setJobPost(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
 			
 			//pull data from your result set
 		/*	 
 			ResultSetMetaData metaData = rs.getMetaData();
 			 
 			int columns = metaData.getColumnCount();
 		
 			//get column names from table!
 			String cols = null; 
 			
 			for (int i = 1; i <= columns; i++) {
 				 cols = metaData.getColumnName(i);
 				 column.add(cols);
 			 }
 			 //get row data from table!
 		
 			 while (rs.next()) {
 				 Vector<Object> row = new Vector<Object>(columns);
   	          
 				 for (int i = 1; i <= columns; i++) {
 					 row.addElement(rs.getObject(i));
 					 
 				 } 
 				jobPostData.addElement(row);
 			 }*/
 			return rs;
 		 } 
 		 catch (SQLException e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 } 
 		 catch (Exception e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 }
 		 return null;
	}
/*	private void setJobPost(int int1, int int2, String string, String string2, String string3, String string4,
			String string5, String string6, String string7) {
		this.user_id = int1;
		this.jobId = int2;
		this.designation = string;
		this.jobDesctiption = string2;
		this.jobType = string3;
		this.createdDate = string4;
		this.location = string5;
		this.expiredDate = string6;
		this.isActive = string7;
		
	}
	public void addJobPost(){}
	public void deleteJobPost(){}
	
	public void displayJobPost(){
	
		 
 	   
		 
	
	
	}*/
	public ResultSet getJobPostFileter1(String f) {
		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String reternJobPost = "select * from job_post where job_type ='"+f+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			return rs;
 		 } 
 		 catch (SQLException e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 } 
 		 catch (Exception e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 }
 		 return null;
	
	}
	public ResultSet getJobPostFileter2(String f) {
		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String reternJobPost = "select * from job_post where job_type ='"+f+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			return rs;
		 } 
		 catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 } 
		 catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return null;
	
	}
	public ResultSet getJobPostFileter3(String f) {
		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String reternJobPost = "select * from job_post where job_created_date '"+f+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			return rs;
		 } 
		 catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 } 
		 catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return null;
	
	}
	public ResultSet getJobPostFileter4(String f) {
		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String reternJobPost = "select * from job_post where job_location ='"+f+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			return rs;
		 } 
		 catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 } 
		 catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return null;
	
	}
	
	public ResultSet applyManyFilters(String a,String b,String c,String d) {
		
		
		try {
			Connection con = Connector.connect1();
			Statement stm = con.createStatement();
			
			if(a.equals("any"))
			{a="%%";}
			 else{}
			if(b.equals("any"))
			{b="%%";}
			 else{}
			if(d.equals("any"))
			{d="%%";}
			 else{}
			 if(c=="any")
			 {c="%%";}
			
 			System.out.println(""+a+""+b+""+""+c+""+d);
 			 if(c=="%%")
			 {
			 System.out.println("loop 1");
			 System.out.println("select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"' AND job_location LIKE'"+d+"'");
	 			String reternJobPost = "select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"' AND job_location LIKE'"+d+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost);
	 			return rs;
			 }
			 else if(c=="past week"){c="1";
			 System.out.println("loop 2");
			 System.out.println("select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"' AND job_created_date > NOW() - INTERVAL "+c+" AND job_location LIKE'"+d+"'");
	 			String reternJobPost = "select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"'  AND job_created_date > NOW() - INTERVAL "+c+" AND job_location LIKE'"+d+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			/*if(rs.next())
	 			{
	 				System.out.println();
	 				System.out.println("1:"+rs.getObject(1)+"2:"+rs.getObject(2)+"3:"+rs.getObject(3)+"4:"+rs.getObject(4));
	 			}*/
	 			return rs;
	 			}
			 else if(c=="past month"){c="4";
			 System.out.println("loop 3");
			 System.out.println("select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"' AND job_created_date > NOW() - INTERVAL "+c+" AND job_location LIKE'"+d+"'");
	 			String reternJobPost = "select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"'  AND job_created_date > NOW() - INTERVAL "+c+" AND job_location LIKE'"+d+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			/*if(rs.next())
	 			{
	 				System.out.println();
	 				System.out.println("1:"+rs.getObject(1)+"2:"+rs.getObject(2)+"3:"+rs.getObject(3)+"4:"+rs.getObject(4));
	 			}*/
	 			return rs;
	 			}
			 else if(c=="past quarter"){c="12";
			 System.out.println("loop 4");
			 System.out.println("select * from job_post where job_type LIKE'"+a+"' AND job_designation LIKE '"+b+"' AND job_created_date > NOW() - INTERVAL "+c+" AND job_location LIKE'"+d+"'");
	 			String reternJobPost = "select * from job_post where job_type LIKE '"+a+"' AND job_designation LIKE '"+b+"'  AND job_created_date > NOW() - INTERVAL "+c+" AND job_location LIKE'"+d+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			/*if(rs.next())
	 			{
	 				System.out.println();
	 				System.out.println("1:"+rs.getObject(1)+"2:"+rs.getObject(2)+"3:"+rs.getObject(3)+"4:"+rs.getObject(4));
	 			}*/
	 			return rs;
	 			}
			 
			 else{
				 System.out.println("loop 5");
	 			System.out.println("select * from job_post where job_type LIKE '"+a+"' AND job_designation LIKE '"+b+"' AND job_location LIKE'"+d+"'");
	 			String reternJobPost = "select * from job_post where job_type LIKE '"+a+"' AND job_designation LIKE '"+b+"' AND job_location LIKE'"+d+"'";
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			/*if(rs.next())
	 			{
	 				System.out.println();
	 				System.out.println("1:"+rs.getObject(1)+"2:"+rs.getObject(2)+"3:"+rs.getObject(3)+"4:"+rs.getObject(4));
	 			}*/
	 			return rs;
			 }
	 			
		 } 
		 catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 } 
		 catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return null;
	
	}
	public ResultSet getJobPost(int user_id2) {
		
		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String reternJobPost = "select * from job_post where user_id="+user_id2;
	 			ResultSet rs = stm.executeQuery(reternJobPost); 
	 			return rs;
 		 } 
 		 catch (SQLException e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 } 
 		 catch (Exception e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 }
 		 return null;
	}
}
