package model;

public class Admin {

	public static int userID;

	public Admin(int userID2) {
	this.userID=userID2;
	System.out.println("inside Admin constructor "+userID);
	}

	

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

}
