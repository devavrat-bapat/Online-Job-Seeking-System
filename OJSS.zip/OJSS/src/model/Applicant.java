package model;

import java.sql.Date;
import javafx.collections.FXCollections;

import java.sql.ResultSet;
import java.sql.SQLException;

import dao.Connector;
import dao.ManageApplicant;
public class Applicant {

	public int user_id;
	public String first_name;
	public String last_name;
	public double curr_sal;
	public String is_monthly;
	public String currency;
	public String cert_degree;
	public String major;
	public String university;
	public Date edu_start_date;
	public Date edu_end_date;
	public double gpa;
	public String role;
	public Date dateOfBirth;
	public String gender;
	public String email_id;
	public String resume;
	public String location;
	public Double phone_no;
	public String employment_status;
	public String summary;
	public String employer_name1;
	public String employer_name2;
	public String employer_name3;
	public String designation1;
	public String designation2;
	public String designation3;
	public Date job_start_date1;
	public Date job_start_date2;
	public Date job_start_date3;
	public String job_location1;
	public String job_location2;
	public String job_location3;
	String job_description1;
	String job_description2;
	String job_description3;
	
	public Applicant(int i){
		this.user_id=i;
		this.role="applicant";
	}
	public Applicant() {
		
	}
		
	
	/*public void setApplicantProfile(ResultSet rs1,ResultSet rs2,ResultSet rs3) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("in setApplicant");
		while(rs1.next())
		{
			rs1.next();
			System.out.println("in rs1"+rs1.getString(2));
		this.first_name = rs1.getString(2);
		this.last_name = rs1.getString(3);
		this.curr_sal = rs1.getDouble(4);
		this.is_monthly = rs1.getString(5);
		this.currency = rs1.getString(6);
		this.phone_no= rs1.getDouble(7);
		this.location= rs1.getString(8);
		this.summary= rs1.getString(10);
		this.resume= rs1.getString(11);
		}
		//this.employment_status= rs1.getString(9);
		
		this.cert_degree = rs2.getString(2);
		this.major = rs2.getString(3);
		this.university = rs2.getString(4);
		this.edu_start_date = rs2.getDate(5);
		this.edu_end_date = rs2.getDate(6);
		this.gpa = rs2.getDouble(7);
		
		this.employer_name1 = rs3.getString(2);
		this.designation1= rs3.getString(3);
		this.job_start_date1= rs3.getDate(4);
		this.job_location1= rs3.getString(5);
		this.job_description1= rs3.getString(6);
		
	}*/
	public void setApplicantProfile(ResultSet rs1,ResultSet rs2,ResultSet rs3) throws SQLException {
		rs1.next();
		System.out.println("4");
			System.out.println("in set rs1"+rs1.getString(2));
		this.first_name = rs1.getString(2);
		this.last_name = rs1.getString(3);
		this.curr_sal = rs1.getDouble(4);
		this.is_monthly = rs1.getString(5);
		this.currency = rs1.getString(6);
		this.phone_no= rs1.getDouble(7);
		this.location= rs1.getString(8);
		this.summary= rs1.getString(9);
		this.resume= rs1.getString(10);
		this.dateOfBirth= rs1.getDate(11);
		this.gender= rs1.getString(12);
		
		System.out.println("dev - gender:"+this.gender);
		rs2.next();
		this.cert_degree = rs2.getString(2);
		this.major = rs2.getString(3);
		this.university = rs2.getString(4);
		this.edu_start_date = rs2.getDate(5);
		this.edu_end_date = rs2.getDate(6);
		this.gpa = rs2.getDouble(7);
		System.out.println("6");
		System.out.println("set app done");
		rs3.next();
		this.employer_name1 = rs3.getString(2);
		this.designation1= rs3.getString(3);
		this.job_start_date1= rs3.getDate(4);
		this.job_location1= rs3.getString(5);
		this.job_description1= rs3.getString(6);
		
		//this.employment_status= rs1.getString(9);
		
		
	}
	
	public int apply(int i){
		
		return 1;
	}
	public ResultSet getApplicant() throws SQLException {
		
		return ManageApplicant.getApplicant();
	}
	public Applicant(String first_name, String last_name, java.sql.Date birth_date, String email_id, String location, Double phone_no) {
		this.first_name = first_name;
		this.last_name = last_name;
		this.dateOfBirth = birth_date;
		this.email_id = email_id;
		this.location = location;
		this.phone_no = phone_no;
		System.out.println("inside constructor "+first_name+last_name+birth_date+email_id+location+phone_no);
	}
}
