package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import dao.Connector;

public class Employer {

	public int user_id;
	public String company_name;
	public String email_id;
	public String industry_type;
	public String location;
	public Date establishment_date;
	public String company_url;
	public String phone_number;
	public String description;
	public String role;
	public String password;

	public Employer(int userID) {
	
		this.user_id = userID;
		this.role = "employer";
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getIndustry_type() {
		return industry_type;
	}

	public void setIndustry_type(String industry_type) {
		this.industry_type = industry_type;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getEstablishment_date() {
		return establishment_date;
	}

	public void setEstablishment_date(Date establishment_date) {
		this.establishment_date = establishment_date;
	}

	public String getCompany_url() {
		return company_url;
	}

	public void setCompany_url(String company_url) {
		this.company_url = company_url;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Employer() {
		
	}

	public Employer(int int1, String string, String string2, String string3, String string4, Date string5,
			String string6, String phone_no, String string7) throws ParseException {
		
		setUser_id(int1);
		setCompany_name(string);
		setEmail_id(string2);
		setIndustry_type(string3);
		setLocation(string4);
		
		
		/*   SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
		   java.util.Date date = sdf1.parse(string5);
		   java.sql.Date sqlStartDate = new Date(date.getDate()); 
		   
		setEstablishment_date(sqlStartDate);*/
		setEstablishment_date(string5);
		setCompany_url(string6);
		setPhone_number(phone_no);
		setDescription(string7);
	}

	public Employer(int i,String string, String string2) {
		System.out.println("in emp constructor");
		setUser_id(i);
		setCompany_name(string);
		setEmail_id(string2);
	}

	public void setEmployerProfile(ResultSet rs1, ResultSet rs2) throws SQLException {
		
		rs1.next();
		company_name=rs1.getString(2);
		email_id=rs1.getString(3);
		industry_type=rs1.getString(4);
		location=rs1.getString(5);
		System.out.println("1");
		establishment_date= rs1.getDate(6);
		System.out.println("2");
		company_url=rs1.getString(7);
		phone_number=rs1.getString(8);
		description=rs1.getString(9);
		//System.out.println("0 "+email_id);
		rs2.next();
		password =rs2.getString(4);
		System.out.println("password = "+password);
	}

	public ResultSet getEmployer() {
		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String returnEmployer = "select * from employer_profile";
	 			ResultSet rs = stm.executeQuery(returnEmployer); 
	 			return rs;
 		 } 
 		 catch (SQLException e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 } 
 		 catch (Exception e) {
 			 // TODO Auto-generated catch block
 			 e.printStackTrace();
 		 }
 		 return null;
	}
	
	public ResultSet getEmployer2() {
		 try {
	 			
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			String returnEmployer = "select user_id,company_name,email_id,industry_type,location,establishment_date,company_url,phone_number,description from employer_profile";
	 			ResultSet rs = stm.executeQuery(returnEmployer); 
	 			return rs;
		 } 
		 catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 } 
		 catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return null;
	}

	public ResultSet applyManyFiltersEmp(String a, String b, String c) {
		 try {
			 Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			ResultSet rs;
			 if(a.equals("any")){a="%%";}
			 if(b.equals("any")){b="%%";}
			
			 if(c.equals("any")){c="%%";
			 	
	 			System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"'");
	 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"'";
	 			rs = stm.executeQuery(reternJobPost); 
			 }
			 else if(c.equals("0-1 year old")){
				 System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date > (NOW() - INTERVAL 1 YEAR)");
		 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date > (NOW() - INTERVAL 1 YEAR)";
		 			 rs = stm.executeQuery(reternJobPost); 
			 }
			 else if(c.equals("2-5 years old")){
				 System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 5 YEAR) AND (NOW() - INTERVAL 1 YEAR)");
		 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 5 YEAR) AND (NOW() - INTERVAL 1 YEAR)";
		 			 rs = stm.executeQuery(reternJobPost); 
			 }
			 else if(c.equals("6-10 years old")){
				 System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 10 YEAR) AND (NOW() - INTERVAL 5 YEAR)");
		 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 10 YEAR) AND (NOW() - INTERVAL 5 YEAR)";
		 			 rs = stm.executeQuery(reternJobPost); 
			 }
			 else if(c.equals("11-20 years old")){
				 System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 20 YEAR) AND (NOW() - INTERVAL 11 YEAR)");
		 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 20 YEAR) AND (NOW() - INTERVAL 11 YEAR)";
		 			 rs = stm.executeQuery(reternJobPost); 
			 }
			 else if(c.equals("21-30 years old")){
				 System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 30 YEAR) AND (NOW() - INTERVAL 21 YEAR)");
		 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 30 YEAR) AND (NOW() - INTERVAL 21 YEAR)";
		 			 rs = stm.executeQuery(reternJobPost); 
			 }
			else if(c.equals("31-50 years old")){
				System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 50 YEAR) AND (NOW() - INTERVAL 31 YEAR)");
	 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date BETWEEN (NOW() - INTERVAL 50 YEAR) AND (NOW() - INTERVAL 31 YEAR)";
	 			 rs = stm.executeQuery(reternJobPost); 
			}
			else if(c.equals("Older")){
				System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date < NOW() - INTERVAL 51 YEAR");
	 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"' AND establishment_date < NOW() - INTERVAL 51 YEAR";
	 			 rs = stm.executeQuery(reternJobPost); 
			}
			else{
				System.out.println("select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"'");
	 			String reternJobPost = "select * from employer_profile where industry_type LIKE'"+a+"' AND location LIKE '"+b+"";
	 			 rs = stm.executeQuery(reternJobPost); 
				
			}
	 			/*if(rs.next())
	 			 * 
	 			 * <String fx:value="1 year old" />
                                                                   		    <String fx:value="5 years old" />
                                                                     		<String fx:value="10 years old" />
                                                                     		<String fx:value="20 years old" />
                                                                     		<String fx:value="30 years old" />
                                                                     		<String fx:value="50 years old" />
                                                                     		<String fx:value="Older" />
	 			{
	 				System.out.println();
	 				System.out.println("1:"+rs.getObject(1)+"2:"+rs.getObject(2)+"3:"+rs.getObject(3)+"4:"+rs.getObject(4));
	 			}*/
	 			return rs;
	 			
	 			
		 } 
		 catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 } 
		 catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return null;
	}

	public ResultSet applyFiltersEmp(String string, String string2, String string3) {
		 try {
			 /*if(a==null){a="%%";}
			 if(b==null){b="%%";}
			 if(c==null){c="%%";}
			 if(d==null){d="%%";}
			 */
	 			Connection con = Connector.connect1();
	 			Statement stm = con.createStatement();
	 			System.out.println("select user_id,company_name,email_id from employer_profile where job_type LIKE'"+string+"' AND job_designation LIKE '"+string2+"' AND job_created_date <'"+string3);
	 			String returnviewEmployer = "select user_id,company_name,email_id from employer_profile";
	 			ResultSet rs = stm.executeQuery(returnviewEmployer); 
	 			/*if(rs.next())
	 			{
	 				System.out.println();
	 				System.out.println("1:"+rs.getObject(1)+"2:"+rs.getObject(2)+"3:"+rs.getObject(3)+"4:"+rs.getObject(4));
	 			}*/
	 			return rs;
	 			
	 			
		 } 
		 catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 } 
		 catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return null;
	}

	
}
