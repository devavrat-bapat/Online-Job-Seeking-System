package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Parent;
import javafx.scene.Scene;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
			Scene scene = new Scene(root,700,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); //not in use
			primaryStage.setScene(scene);
			primaryStage.setTitle("Welcome to Job Seeking System");
		
			String a="any";
			String b = "%";
			String c="$%%";
			String d= "%%";
			
			System.out.println("a:"+a+"b:"+b+"c:"+c+"d:"+d);
			if(a.equals("any"))
			{a="%%";}
				System.out.println(""+a);
			primaryStage.initStyle(StageStyle.UTILITY);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}