package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import dao.Connector;
import dao.ManageEmployer;
import dao.NewJobPost;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Callback;
import model.Applicant;
import model.Employer;
import model.JobPost;

public class HomepageAdminController implements Initializable{

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
		// Setting Tab Manage Employer
		// setEmployerTable(); loadEmployerTable();
		
		
		// Setting Tab Manage Applicant
	//	 setManageApplicantTable(); 
		 
		setManageEmployerTable();	
		
		// Setting Tab Manage Job Posts
		setJobPostTable();
		try {
//			loadManageApplicantTable();
			loadDataintoManageEmployer();
			loadJobPostTable();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	/*
	 * 
	 * 
	 * Common Members
	 * 
	 * 
	 */
	
	

@FXML
    private ImageView imageanim;
    @FXML
    private ImageView imagelogo;
    @FXML
    private JFXButton buttonLogoutAdmin;
    /**
	 * 
	 * 
	 * 
	 * Logout Button 
	 * 
	 */

@FXML
    void buttonLogoutAdmin(ActionEvent event) throws IOException {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Sure! You want to Logout");
		alert.setContentText("");

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK) {

			buttonLogoutAdmin.getScene().getWindow().hide();

			Stage signup = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
			Scene scene = new Scene(root, 700, 600);
			signup.setScene(scene);
			signup.show();
		}

    }
	
	
	
	
	
	
	
	
//Members for Manage Employer


	@FXML
	private TableColumn<?, ?> colUserEmp,colCompanyNameEmp,colEmailIdEmp,colIndustryTypeEmp,colLocationEmp;
	@FXML
	private TableColumn<?, ?> colEstablishmentDateEmp,colPhoneNoEmp,columnCompanyUrl;
	@FXML
	private TableColumn<Employer, Boolean> colEditEmp,colDelEmp;
	@FXML
	private TableView<Employer> tableManageEmployer;
	

@FXML
private JFXTextField company_nameEmp,email_idEmp,locationEmp,phoneEmp;	
@FXML
private JFXComboBox<?> industry_typeEmp;
@FXML
private DatePicker establishmentDateEmp;
	
@FXML
private JFXComboBox<?> industryType;
@FXML
private JFXTextField emailIdEmployer;
@FXML
private JFXTextField locationEmployer;
	ObservableList<Employer> ol2;
	int tempEmpId=0;

	public void setManageEmployerTable() {
		System.out.println("13");
		colUserEmp.setCellValueFactory(new PropertyValueFactory<>("user_id"));
		colCompanyNameEmp.setCellValueFactory(new PropertyValueFactory<>("company_name"));
		colEmailIdEmp.setCellValueFactory(new PropertyValueFactory<>("email_id"));
		colIndustryTypeEmp.setCellValueFactory(new PropertyValueFactory<>("industry_type"));
		colLocationEmp.setCellValueFactory(new PropertyValueFactory<>("location"));
		colEstablishmentDateEmp.setCellValueFactory(new PropertyValueFactory<>("establishment_date"));
		colPhoneNoEmp.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
		colEditEmp.setCellFactory(cellFactory4);
		colDelEmp.setCellFactory(cellFactory5);
	}

	private void loadDataintoManageEmployer() throws SQLException, ParseException {

		Employer emp1 = new Employer();
		ResultSet rs3 = emp1.getEmployer2();
		ol2 = FXCollections.observableArrayList();
		int i = 1;
		while (rs3.next()) {
			System.out.println("emp row " + i);
			i++;
			ol2.add(new Employer(rs3.getInt(1), rs3.getString(2), rs3.getString(3), rs3.getString(4), rs3.getString(5),
					rs3.getDate(6), rs3.getString(7), rs3.getString(8), rs3.getString(9)));
		}
		tableManageEmployer.setItems(ol2);
	}
	
	
	Callback<TableColumn<Employer, Boolean>, TableCell<Employer, Boolean>> cellFactory4 = 
			new Callback<TableColumn<Employer, Boolean>, TableCell<Employer, Boolean>>()
	{
		@Override
		public TableCell<Employer, Boolean> call( final TableColumn<Employer, Boolean> param)
		{
			final TableCell<Employer, Boolean> cell = new TableCell<Employer, Boolean>()
			{
				Image imgEdit = new Image(getClass().getResourceAsStream("/imagetemp/edit.png"));
				final Button btnEditEmp = new Button();
				
				@Override
				public void updateItem(Boolean check, boolean empty)
				{
					super.updateItem(check, empty);
					if(empty)
					{
						setGraphic(null);
						setText(null);
					}
					else{
						btnEditEmp.setOnAction(e ->{
							System.out.println("3");
							Employer user = getTableView().getItems().get(getIndex());
							try {
								tempEmpId=1;
								updateUser(user);
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						});
						
						btnEditEmp.setStyle("-fx-background-color: transparent;");
						ImageView iv = new ImageView();
				        iv.setImage(imgEdit);
				        iv.setPreserveRatio(true);
				        iv.setSmooth(true);
				        iv.setCache(true);
				        btnEditEmp.setGraphic(iv);
						
						setGraphic(btnEditEmp);
						setAlignment(Pos.CENTER);
						setText(null);
					}
				}

				private void updateUser(Employer user) throws SQLException {
					
					System.out.println("Emp id ="+user.user_id);
					editEmployer(user.user_id);		
					
				}

				private void editEmployer(int empId) throws SQLException {
					
					Connection con = Connector.connect1();
					Statement stm = con.createStatement();
					ResultSet rsEmp = stm.executeQuery("select * from employer_profile where user_id="+empId);
					System.out.println("1");
					while(rsEmp.next())
					{
					System.out.println(""+rsEmp.getString(2)+""+rsEmp.getString(4)+""+rsEmp.getString(3)+""+rsEmp.getString(8)+""+""+rsEmp.getString(5)+""+""+rsEmp.getString(6)+"");
					tempEmpId = rsEmp.getInt(1);
					company_nameEmp.setText(rsEmp.getString(2));
				//	industry_typeEmp.setAccessibleText(rsEmp.getString(4));
					email_idEmp.setText(rsEmp.getString(3));
					phoneEmp.setText(rsEmp.getString(8));
					locationEmp.setText(rsEmp.getString(5));
					establishmentDateEmp.setValue(rsEmp.getDate(6).toLocalDate());
					}
					
				}
			};
			return cell;
		}
	};
	


	@FXML
	void saveEmployer(ActionEvent event) throws SQLException{
		
		Date dt = new Date();

		java.text.SimpleDateFormat sdf = 
		     new java.text.SimpleDateFormat("yyyy-MM-dd");
		String currentTime = sdf.format(dt);
		
		if(tempEmpId!=0)
		{
			char status = ManageEmployer.updateAdminEmployer(tempEmpId,company_nameEmp.getText(),industry_typeEmp.getValue().toString(),email_idEmp.getText(),phoneEmp.getText(),locationEmp.getText(),establishmentDateEmp.getValue());
			System.out.println("Emp id to edit is "+tempEmpId);
			System.out.println("Status is "+status);
			if(status=='s')
			{
				setManageEmployerTable();
				System.out.println("here 11");
				try {
					
					System.out.println("here 12");
					loadDataintoManageEmployer();
					resetEmployer();
						
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Success");
					alert.setHeaderText("Employer Updated");
					alert.setContentText("");
					alert.showAndWait();
				} catch (SQLException e) {
					
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			else{
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Error");
				alert.setHeaderText("Try again");
				alert.setContentText("");
				alert.showAndWait();
			
			}
			tempEmpId=0;
		}
		else{
			resetEmployer();
			
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Error");
			alert.setHeaderText("Please choose an Employer to Edit");
			alert.setContentText("");
			alert.showAndWait();
			
		}
	}
	public void resetEmployer(){
		company_nameEmp.setText(null);
		industry_typeEmp.setValue(null);
		email_idEmp.setText(null);
		phoneEmp.setText(null);
		locationEmp.setText(null);
		establishmentDateEmp.setValue(null);
	}
	
	/*
	 * Deleting Job Post
	 * 
	 */
	
	Callback<TableColumn<Employer, Boolean>, TableCell<Employer, Boolean>> cellFactory5 = 
			new Callback<TableColumn<Employer, Boolean>, TableCell<Employer, Boolean>>()
	{
		@Override
		public TableCell<Employer, Boolean> call( final TableColumn<Employer, Boolean> param)
		{
			final TableCell<Employer, Boolean> cell = new TableCell<Employer, Boolean>()
			{
				Image imgEdit = new Image(getClass().getResourceAsStream("/imagetemp/dele.png"));
				final Button btnDelEmp= new Button();
				
				@Override
				public void updateItem(Boolean check, boolean empty)
				{
					super.updateItem(check, empty);
					if(empty)
					{
						setGraphic(null);
						setText(null);
					}
					else{
						btnDelEmp.setOnAction(e ->{
							System.out.println("reached ");
							Employer EmployerToDelete = getTableView().getItems().get(getIndex());
							try {
								tempJobId=1;
								deletePost(EmployerToDelete);
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						});
						
						btnDelEmp.setStyle("-fx-background-color: transparent;");
						ImageView iv = new ImageView();
				        iv.setImage(imgEdit);
				        iv.setPreserveRatio(true);
				        iv.setSmooth(true);
				        iv.setCache(true);
				        btnDelEmp.setGraphic(iv);
						
						setGraphic(btnDelEmp);
						setAlignment(Pos.CENTER);
						setText(null);
					}
				}

						private void deletePost(Employer EmployerToDelete) throws SQLException, ParseException {

							System.out.println("Employer id =" + EmployerToDelete.user_id);
							System.out.println("2");
							deleteEmployer(EmployerToDelete.user_id);

						}

						private void deleteEmployer(int empId) throws SQLException, ParseException {

							Alert alert = new Alert(AlertType.CONFIRMATION);
							alert.setTitle("Confirmation Dialog");
							alert.setHeaderText("Sure You want to delete this Employer");
							alert.setContentText("");

							Optional<ButtonType> result = alert.showAndWait();
							if (result.get() == ButtonType.OK) {

								char status = ManageEmployer.deleteEmployer(empId);
								if(status=='s')
								{
									Alert alert1 = new Alert(AlertType.INFORMATION);
									alert1.setTitle("Confirmation Dialog");
									alert1.setHeaderText("Employer deleted successfully.");
									alert1.setContentText("");
									alert1.showAndWait();
									setManageEmployerTable();
									loadDataintoManageEmployer();
								}
								else if(status =='f')
								{
									Alert alert1 = new Alert(AlertType.INFORMATION);
									alert1.setTitle("Message");
									alert1.setHeaderText("Operation performed");
									alert1.setContentText("");
									alert1.showAndWait();
								}
								setManageEmployerTable();
								loadDataintoManageEmployer();
							}
						}
			};
			return cell;
		}
	};
	
	
	@FXML
	void cancelEmployer(ActionEvent event) throws SQLException {

		company_nameEmp.setText(null);
		industry_typeEmp.setValue(null);
		email_idEmp.setText(null);
		phoneEmp.setText(null);
		locationEmp.setText(null);
		establishmentDateEmp.setValue(null);
		tempEmpId = 0;
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Done");
		alert.setHeaderText("Task Cancelled");
		alert.setContentText("");
		alert.showAndWait();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	

	
	
	   
    // Members for Manage Applicant
//Manage Applicant

//Members for Manage Applicant
	@FXML
	private TableColumn<?, ?> colFirstNameApp,colLastNameApp,colDateOfBirthApp,colEmailIdApp,colLocationApp;
	@FXML
	private TableColumn<?, ?> colPhoneApp;
	@FXML
	private TableColumn<Applicant, Boolean> colEditApp,colDeleteApp;
	@FXML
	private TableView<Applicant> tableManageApplicant;
	
	@FXML
	private JFXTextField firstNameApp;
	@FXML
	private JFXTextField lastNameApp;
	@FXML
	private JFXTextField emailIdApp; 
	@FXML
	private JFXTextField locationApp; 
	@FXML
	private JFXTextField phoneApp;
	@FXML
	private JFXDatePicker dateOfBirthApp;
	
	Applicant app1;
	ObservableList<Applicant> olApp;
	int tempApplicantId=0;
  
  private void setManageApplicantTable() {
		
		colFirstNameApp.setCellValueFactory(new PropertyValueFactory<>("first_name"));
		colLastNameApp.setCellValueFactory(new PropertyValueFactory<>("last_name"));
		colDateOfBirthApp.setCellValueFactory(new PropertyValueFactory<>("dateOfBirth"));
		colEmailIdApp.setCellValueFactory(new PropertyValueFactory<>("email_id"));
		colLocationApp.setCellValueFactory(new PropertyValueFactory<>("location"));
		colPhoneApp.setCellValueFactory(new PropertyValueFactory<>("phone_no"));
		colEditApp.setCellValueFactory(new PropertyValueFactory<>("dummy1"));
		colDeleteApp.setCellValueFactory(new PropertyValueFactory<>("dummy2"));
//		colEditApp.setCellFactory(cellFactory2);
//		colDeleteApp.setCellFactory(cellFactory3);
	}
    
    
  private void loadManageApplicantTable() throws SQLException {
		app1 = new Applicant();
		ResultSet rsApp = app1.getApplicant();
		olApp = FXCollections.observableArrayList();
		int i=1;
		while(rsApp.next()){
			System.out.println("Applicant row"+i);
			i++;
			System.out.println(rsApp.getString(2)+""+rsApp.getString(3)+""+rsApp.getDate(12)+""+rsApp.getString(15)+""+rsApp.getString(8)+""+rsApp.getDouble(7));
			olApp.add(new Applicant(rsApp.getString(2),rsApp.getString(3),rsApp.getDate(12),rsApp.getString(15),rsApp.getString(8),rsApp.getDouble(7)));
		}
		tableManageApplicant.setItems(olApp);		
	}
	
  
  
  
  
  
  
  
  
  
  

	
	
    
    
    
  //Manage Job POst

  //Members for Manage Job Post
  	@FXML
     private TableColumn<?, ?> columnUserid,columnLocation,columnIsactive,columnExpirydate,columnJobtype;
  	@FXML
  	private TableColumn<?, ?> columnJobid,columnDescription,columnCreatedate,columnDesignation;
  	@FXML
  	private TableColumn<JobPost, Boolean> colEdit,colDelete;
  	@FXML
  	private TableView<JobPost> tableJobPost;
  	@FXML
  	private JFXDatePicker job_expirydate;
  	
      
      @FXML
      private JFXTextField job_designation;
      @FXML
      private JFXComboBox<?> job_type;
      @FXML
      private JFXTextField job_description;
      @FXML
      private JFXTextField job_location;
      @FXML
      private JFXDatePicker job_expiryDate;
  	JobPost jb1;
  	ObservableList<JobPost> ol;
      int tempJobId=0;
      
  	
  	/*
  	 * Methods
  	 * 
  	 * To
  	 * 
  	 * Manage Job Post
  	 * 
  	 * 
  	 */
  	

  	private void setJobPostTable() {
  		
  		columnUserid.setCellValueFactory(new PropertyValueFactory<>("user_id"));
  		columnJobid.setCellValueFactory(new PropertyValueFactory<>("jobId"));
  		columnJobtype.setCellValueFactory(new PropertyValueFactory<>("jobType"));
  		columnDesignation.setCellValueFactory(new PropertyValueFactory<>("designation"));
  		columnDescription.setCellValueFactory(new PropertyValueFactory<>("jobDesctiption"));
  		columnLocation.setCellValueFactory(new PropertyValueFactory<>("location"));
  		columnCreatedate.setCellValueFactory(new PropertyValueFactory<>("createdDate"));
  		columnExpirydate.setCellValueFactory(new PropertyValueFactory<>("expiredDate"));
  		columnIsactive.setCellValueFactory(new PropertyValueFactory<>("isActive"));	
  		colEdit.setCellFactory(cellFactory);
  		colDelete.setCellFactory(cellFactory1);
  	}


  	private void loadJobPostTable() throws SQLException {
  		jb1 = new JobPost();
  		ResultSet rs = jb1.getJobPost();
  		ol = FXCollections.observableArrayList();
  		int i=1;
  		while(rs.next()){
  			System.out.println("job post row "+i);
  			i++;
  			System.out.println(""+rs.getInt(1)+""+rs.getInt(2)+""+rs.getString(3)+""+rs.getString(4)+""+rs.getString(5)+""+rs.getString(6)+""+""+rs.getObject(7));
  			ol.add(new JobPost(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),""+rs.getObject(7),""+rs.getObject(8)));
  		}
  		tableJobPost.setItems(ol);		
  	}
  	
  	/*
  	 * Adding Edit option for every Record
  	 */
  	
  	Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>> cellFactory = 
  			new Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>>()
  	{
  		@Override
  		public TableCell<JobPost, Boolean> call( final TableColumn<JobPost, Boolean> param)
  		{
  			final TableCell<JobPost, Boolean> cell = new TableCell<JobPost, Boolean>()
  			{
  				Image imgEdit = new Image(getClass().getResourceAsStream("/imagetemp/edit.png"));
  				final Button btnEdit = new Button();
  				
  				@Override
  				public void updateItem(Boolean check, boolean empty)
  				{
  					super.updateItem(check, empty);
  					if(empty)
  					{
  						setGraphic(null);
  						setText(null);
  					}
  					else{
  						btnEdit.setOnAction(e ->{
  							System.out.println("3");
  							JobPost user = getTableView().getItems().get(getIndex());
  							try {
  								tempJobId=1;
  								updateUser(user);
  							} catch (Exception e1) {
  								// TODO Auto-generated catch block
  								e1.printStackTrace();
  							}
  						});
  						
  						btnEdit.setStyle("-fx-background-color: transparent;");
  						ImageView iv = new ImageView();
  				        iv.setImage(imgEdit);
  				        iv.setPreserveRatio(true);
  				        iv.setSmooth(true);
  				        iv.setCache(true);
  						btnEdit.setGraphic(iv);
  						
  						setGraphic(btnEdit);
  						setAlignment(Pos.CENTER);
  						setText(null);
  					}
  				}

  				private void updateUser(JobPost user) throws SQLException {
  					
  					System.out.println("Job id ="+user.jobId);
  					System.out.println("2");
  					editJobPost(user.jobId);		
  					
  				}

  				private void editJobPost(int jobId) throws SQLException {
  					
  					Connection con = Connector.connect1();
  					Statement stm = con.createStatement();
  					ResultSet rs2 = stm.executeQuery("select * from job_post where job_id="+jobId);
  					System.out.println("1");
  					while(rs2.next())
  					{
  			//		System.out.println(""+rs2.getString(4)+""+rs2.getString(3)+""+rs2.getString(6)+""+rs2.getString(5)+"");
  					tempJobId = rs2.getInt(1);
  					job_designation.setText(rs2.getString(4));
  					 job_type.setAccessibleText(rs2.getString(3));
  					 job_location.setText(rs2.getString(6));
  		//			 job_type.setValue(rs2.getString(3));
  					 job_description.setText(rs2.getString(5));
  					 job_expirydate.setValue(rs2.getDate(8).toLocalDate());
  					}
  					
  				}
  			};
  			return cell;
  		}
  	};
  	


  @FXML
  	void saveJobPost(ActionEvent event) throws SQLException{
  		
  		Date dt = new Date();

  		java.text.SimpleDateFormat sdf = 
  		     new java.text.SimpleDateFormat("yyyy-MM-dd");
  		String currentTime = sdf.format(dt);
  		
  		if(tempJobId!=0)
  		{
  			char status = NewJobPost.updateAdminJobPost(tempJobId,job_type.getValue(),job_designation.getText(),job_description.getText(),job_location.getText(),currentTime,job_expirydate.getValue());
  			System.out.println("job id to edit is "+tempJobId);
  			System.out.println("Status is "+status);
  			if(status=='s')
  			{
  				setJobPostTable();
  				System.out.println("here 11");
  				try {
  					
  					System.out.println("here 12");
  					loadJobPostTable();
  					job_type.setValue(null);
  					job_designation.clear();
  					job_description.clear();
  					job_location.clear();
  					job_expirydate.setValue(null);
  					Alert alert = new Alert(AlertType.INFORMATION);
  					alert.setTitle("Success");
  					alert.setHeaderText("Job Updated");
  					alert.setContentText("");
  					alert.showAndWait();
  				} catch (SQLException e) {
  					Alert alert = new Alert(AlertType.INFORMATION);
  					alert.setTitle("Error");
  					alert.setHeaderText("Cannot Update this Job post");
  					alert.setContentText("");
  					alert.showAndWait();
  					e.printStackTrace();
  				}
  				
  			}
  			else{
  				Alert alert = new Alert(AlertType.INFORMATION);
  				alert.setTitle("Error");
  				alert.setHeaderText("Please select a valid Job post");
  				alert.setContentText("");
  				alert.showAndWait();
  			
  			}
  			tempJobId=0;
  		}
  	}
  	
  	
  	/*
  	 * Deleting Job Post
  	 * 
  	 */
  	Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>> cellFactory1 = 
  			new Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>>()
  	{
  		@Override
  		public TableCell<JobPost, Boolean> call( final TableColumn<JobPost, Boolean> param)
  		{
  			final TableCell<JobPost, Boolean> cell = new TableCell<JobPost, Boolean>()
  			{
  				Image imgEdit = new Image(getClass().getResourceAsStream("/imagetemp/dele.png"));
  				final Button btnDel= new Button();
  				
  				@Override
  				public void updateItem(Boolean check, boolean empty)
  				{
  					super.updateItem(check, empty);
  					if(empty)
  					{
  						setGraphic(null);
  						setText(null);
  					}
  					else{
  						btnDel.setOnAction(e ->{
  							System.out.println("reached ");
  							JobPost jobPostToDelete = getTableView().getItems().get(getIndex());
  							try {
  								tempJobId=1;
  								deletePost(jobPostToDelete);
  							} catch (Exception e1) {
  								// TODO Auto-generated catch block
  								e1.printStackTrace();
  							}
  						});
  						
  						btnDel.setStyle("-fx-background-color: transparent;");
  						ImageView iv = new ImageView();
  				        iv.setImage(imgEdit);
  				        iv.setPreserveRatio(true);
  				        iv.setSmooth(true);
  				        iv.setCache(true);
  				        btnDel.setGraphic(iv);
  						
  						setGraphic(btnDel);
  						setAlignment(Pos.CENTER);
  						setText(null);
  					}
  				}

  				private void deletePost(JobPost jobPostToDelete) throws SQLException {
  					
  					System.out.println("Job to delete ="+jobPostToDelete.jobId);
  					System.out.println("2");
  					deleteJobPost(jobPostToDelete.jobId);		
  					
  				}

  				private void deleteJobPost(int jobId) throws SQLException {
  					
  					
  					Alert alert = new Alert(AlertType.CONFIRMATION);
  					alert.setTitle("Confirmation Dialog");
  					alert.setHeaderText("Sure You want to delete this job post");
  					alert.setContentText("");

  					Optional<ButtonType> result = alert.showAndWait();
  					if (result.get() == ButtonType.OK) {

  					Connection con = Connector.connect1();
  					Statement stm = con.createStatement();
  					System.out.println("Inside deleting Jobs Post");
  					stm.executeUpdate("delete from job_post where job_id="+jobId);
  					setJobPostTable();
  					loadJobPostTable();					
  					}	
  				}
  			};
  			return cell;
  		}
  	};
  	
  	
  @FXML
  	void cancelJobPost(ActionEvent event) throws SQLException{
  		job_type.setValue(null);
  		job_designation.clear();
  		job_description.clear();
  		job_location.clear();
  		job_expirydate.setValue(null);
  		tempJobId=0;
  		Alert alert = new Alert(AlertType.CONFIRMATION);
  		alert.setTitle("Done");
  		alert.setHeaderText("Task Cancelled");
  		alert.setContentText("");
  		alert.showAndWait();
  	}
	
	
	
	
	 
	

}

