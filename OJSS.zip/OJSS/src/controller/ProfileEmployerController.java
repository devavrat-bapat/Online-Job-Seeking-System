package controller;


import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import model.Employer;

public class ProfileEmployerController implements Initializable{

	  @FXML
	    private JFXTextField email_id;

	    @FXML
	    private JFXTextField phone_no;

	    @FXML
	    private ImageView imageanim;

	    @FXML
	    private ImageView profile_pic;

	    @FXML
	    private JFXTextField industry_type;

	    @FXML
	    private JFXTextField establishment_date;

	    @FXML
	    private JFXTextField url;

	    @FXML
	    private AnchorPane paneProfileEmployer;

	    @FXML
	    private ImageView imagelogo;

	    @FXML
	    private JFXTextField user_id;

	    @FXML
	    private JFXTextField company_name;

	    @FXML
	    private JFXTextField location1;

	    @FXML
	    private JFXTextField desc;

		String a,b,c,d,e;
		
	public ProfileEmployerController(Employer e1) {
		
		a = e1.email_id;
		b= e1.company_name;
		c = e1.industry_type;
		d = e1.location;
		System.out.println("a "+a+"b"+b+"c"+c+"d"+d);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		email_id.setText(a);
		company_name.setText(b);
		industry_type.setText(c);
		location1.setText(d);
		
	}

	

}
