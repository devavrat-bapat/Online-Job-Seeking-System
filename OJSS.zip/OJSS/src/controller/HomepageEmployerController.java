package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Optional;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;


import dao.ApplyForJob;
import dao.Connector;
import dao.ManageEmployer;
import dao.NewJobPost;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Callback;
import model.Employer;
import model.JobPost;

public class HomepageEmployerController implements Initializable{

	@FXML
    private TableColumn<?, ?> columnUserid;
	@FXML
    private TableColumn<?, ?> columnLocation;
	 @FXML
	    private TableColumn<?, ?> columnIsactive;

	    @FXML
	    private TableColumn<?, ?> columnExpirydate;
	    @FXML
	    private TableColumn<?, ?> columnJobtype;
	    @FXML
	    private TableColumn<?, ?> columnJobid;
	    @FXML
	    private TableColumn<?, ?> columnDescription;
	    @FXML
	    private TableColumn<?, ?> columnCreatedate;
	    @FXML
	    private TableColumn<?, ?> columnDesignation;
	    @FXML
	    private TableColumn<JobPost, Boolean> colEdit;
	    @FXML
	    private TableView<JobPost> tableJobPost;
	@FXML
	private ImageView imageanim;

	@FXML
	private ImageView imagelogo;

	@FXML
	private JFXButton buttonLogout;

	@FXML
	private JFXButton buttonEditProfile;

	@FXML
	private JFXTextField textCompanyName;

	@FXML
	private JFXTextField textEmailId;

	@FXML
	private JFXTextField textIndustryType;

	@FXML
	private JFXTextField textLocation;

	@FXML
	private JFXTextField textCompanyURL;

	@FXML
	JFXDatePicker establishment_date;
	
	@FXML
	private JFXTextField textDescription;
	@FXML
	JFXTextField job_designation;
	@FXML
	JFXComboBox<?> job_type;
	@FXML
	JFXTextField job_location;
	@FXML
	JFXTextField job_description;
	@FXML
	JFXDatePicker job_expirydate;
	@FXML
	JFXPasswordField textConfirmPassword;
	@FXML
	JFXPasswordField textPassword;
	@FXML
	JFXTextField textPhone;

	JobPost jb1;
	ObservableList<JobPost> ol;
	int tempJobId=0;
	private Employer e1;
	
	public HomepageEmployerController(Employer e1) {
		this.e1=e1;
		
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		displayProfile();
		
		setJobPostTable();
		System.out.println("here 11");
		try {
			
			System.out.println("here 12");
			loadJobPostTable();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void displayProfile() {
		 
		System.out.println("text field"+textCompanyName.getText()+"\n*********: "+e1.phone_number);
		textCompanyName.setText(e1.company_name);;

			textEmailId.setText(e1.email_id);;

			textIndustryType.setText(e1.industry_type);;

			textLocation.setText(e1.location);;

			textCompanyURL.setText(e1.company_url);;
			
			textDescription.setText(e1.description);
			establishment_date.setValue(e1.establishment_date.toLocalDate());
			
			textPhone.setText(e1.phone_number.toString());
			textPassword.setText(e1.password);
			textConfirmPassword.setText(e1.password);
			//textConfirmPassword.setText(e1);
		
	}
	private void setJobPostTable() {
		
		columnUserid.setCellValueFactory(new PropertyValueFactory<>("user_id"));
		columnJobid.setCellValueFactory(new PropertyValueFactory<>("jobId"));
		columnJobtype.setCellValueFactory(new PropertyValueFactory<>("jobType"));
		columnDesignation.setCellValueFactory(new PropertyValueFactory<>("designation"));
		columnDescription.setCellValueFactory(new PropertyValueFactory<>("jobDesctiption"));
		columnLocation.setCellValueFactory(new PropertyValueFactory<>("location"));
		columnCreatedate.setCellValueFactory(new PropertyValueFactory<>("createdDate"));
		columnExpirydate.setCellValueFactory(new PropertyValueFactory<>("expiredDate"));
		columnIsactive.setCellValueFactory(new PropertyValueFactory<>("isActive"));	
	//	columnAction1.setCellValueFactory(new PropertyValueFactory<>("btn1"));	
		colEdit.setCellFactory(cellFactory);
	}
	
	private void loadJobPostTable() throws SQLException {
		jb1 = new JobPost();
		ResultSet rs = jb1.getJobPost(e1.user_id);
		ol = FXCollections.observableArrayList();
		int i=1;
		while(rs.next()){
			System.out.println("job post row "+i);
			i++;
			ol.add(new JobPost(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),""+rs.getObject(7),""+rs.getObject(8)));
		}
		tableJobPost.setItems(ol);	
		
	}
	Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>> cellFactory = 
			new Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>>()
	{
		@Override
		public TableCell<JobPost, Boolean> call( final TableColumn<JobPost, Boolean> param)
		{
			final TableCell<JobPost, Boolean> cell = new TableCell<JobPost, Boolean>()
			{
				Image imgEdit = new Image(getClass().getResourceAsStream("/imagetemp/edit.png"));
				final Button btnEdit = new Button();
				
				@Override
				public void updateItem(Boolean check, boolean empty)
				{
					super.updateItem(check, empty);
					if(empty)
					{
						setGraphic(null);
						setText(null);
					}
					else{
						btnEdit.setOnAction(e ->{
							System.out.println("3");
							JobPost user = getTableView().getItems().get(getIndex());
							try {
								updateUser(user);
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						});
						
						btnEdit.setStyle("-fx-background-color: transparent;");
						ImageView iv = new ImageView();
				        iv.setImage(imgEdit);
				        iv.setPreserveRatio(true);
				        iv.setSmooth(true);
				        iv.setCache(true);
						btnEdit.setGraphic(iv);
						
						setGraphic(btnEdit);
						setAlignment(Pos.CENTER);
						setText(null);
					}
				}

				private void updateUser(JobPost user) throws SQLException {
					
					System.out.println("Job id ="+user.jobId);
					System.out.println("2");
					editJobPost(user.jobId);		
					Alert alert = new Alert(AlertType.CONFIRMATION);
					
					if(1==0)
					{
					alert.setTitle("Application Status");
					alert.setHeaderText("Successfully Applied");
					alert.setContentText("");
					}
					else
					{
						alert.setTitle("Application Status");
						alert.setHeaderText("Cannot Apply");
						alert.setContentText("");
						
					}
					//alert.showAndWait();
				}

				private void editJobPost(int jobId) throws SQLException {
					
					Connection con = Connector.connect1();
					Statement stm = con.createStatement();
					ResultSet rs2 = stm.executeQuery("select * from job_post where job_id="+jobId);
					System.out.println("1");
					while(rs2.next())
					{
						System.out.println(""+rs2.getString(4)+""+rs2.getString(3)+""+rs2.getString(6)+""+rs2.getString(5)+"");
					tempJobId = rs2.getInt(1);
					job_designation.setText(rs2.getString(4));
					 job_type.setAccessibleText(rs2.getString(3));
					 job_location.setText(rs2.getString(6));
					//2 job_type.setSelectionModel(rs2.getString(3));
					 job_description.setText(rs2.getString(5));
					 job_expirydate.setValue(rs2.getDate(8).toLocalDate());
					}
					
				}
			};
			return cell;
		}
	};


	@FXML
	void logout(ActionEvent event) throws IOException {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Sure! You want to Logout");
		alert.setContentText("");

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK) {

			buttonLogout.getScene().getWindow().hide();

			Stage signup = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
			Scene scene = new Scene(root, 700, 600);
			signup.setScene(scene);
			signup.show();
		}
	}

	@FXML
	void saveJobPost(ActionEvent event) throws SQLException{
		
		Date dt = new Date();

		java.text.SimpleDateFormat sdf = 
		     new java.text.SimpleDateFormat("yyyy-MM-dd");
		String currentTime = sdf.format(dt);
		if(tempJobId==0)
		{
		
		System.out.println(""+e1.user_id+""+job_type.getValue()+""+job_designation.getText()+""+job_description.getText()+""+job_location.getText()+""+currentTime+""+job_expirydate.getValue());
		char status = NewJobPost.addJobPost(e1.user_id,job_type.getValue(),job_designation.getText(),job_description.getText(),job_location.getText(),currentTime,job_expirydate.getValue());
		System.out.println("Status is "+status);
		if(status=='s')
		{
			setJobPostTable();
			System.out.println("here 11");
			try {
				
				System.out.println("here 12");
				loadJobPostTable();
				job_type.setValue(null);
				job_designation.clear();
				job_description.clear();
				job_location.clear();
				job_expirydate.setValue(null);
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Success");
				alert.setHeaderText("Job Created");
				alert.setContentText("");
				alert.showAndWait();
			} catch (SQLException e) {
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Error");
				alert.setHeaderText("Cannot Create this job post");
				alert.setContentText("");
				alert.showAndWait();
				e.printStackTrace();
			}
			
		}
		else
		{
			
		}
		tempJobId=0;
		}
		else
		{
			char status = NewJobPost.updateJobPost(e1.user_id,tempJobId,job_type.getValue(),job_designation.getText(),job_description.getText(),job_location.getText(),currentTime,job_expirydate.getValue());
			System.out.println("job id to edit is "+tempJobId);
			System.out.println("Status is "+status);
			if(status=='s')
			{
				setJobPostTable();
				System.out.println("here 11");
				try {
					
					System.out.println("here 12");
					loadJobPostTable();
					job_type.setValue(null);
					job_designation.clear();
					job_description.clear();
					job_location.clear();
					job_expirydate.setValue(null);
					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Success");
					alert.setHeaderText("Job Updated");
					alert.setContentText("");
					alert.showAndWait();
				} catch (SQLException e) {
					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Error");
					alert.setHeaderText("Cannot Update this Job post");
					alert.setContentText("");
					alert.showAndWait();
					e.printStackTrace();
				}
				
			}
			tempJobId=0;
		}
	}
	@FXML
	void cancel(ActionEvent event) throws SQLException{
		job_type.setValue(null);
		job_designation.clear();
		job_description.clear();
		job_location.clear();
		job_expirydate.setValue(null);
		tempJobId=0;
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Done");
		alert.setHeaderText("Task Cancelled");
		alert.setContentText("");
		alert.showAndWait();
	}
	@FXML
	void editProfile(ActionEvent event) throws SQLException {
		
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Sure you want to make changes?");
		
		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK) {
			
			char status= ManageEmployer.updateProfile(
					textCompanyName.getText(),
					textEmailId.getText(),
					textIndustryType.getText(),
					textLocation.getText(),
					textCompanyURL.getText(),
					textDescription.getText(),
					establishment_date.getValue(),
					textPhone.getText(),
					textPassword.getText(),
					textConfirmPassword.getText());
				if(status=='s')
				{
					Alert alert1 = new Alert(AlertType.INFORMATION);
					alert1.setTitle("Success");
					alert1.setHeaderText("Profile Updated");
					alert1.showAndWait();
					
				}
				else{
					Alert alert1 = new Alert(AlertType.INFORMATION);
					alert1.setTitle("Error");
					alert1.setHeaderText("Profile could not be Updated");
					alert1.showAndWait();
				}	
		}	
	}
	
	
	@FXML
	void applyFiltersApplicant(ActionEvent event){
		
	}
}
