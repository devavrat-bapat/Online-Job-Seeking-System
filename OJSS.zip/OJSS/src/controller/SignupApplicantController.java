
package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.chrono.ChronoLocalDate;
import java.util.Calendar;
import java.util.Optional;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import dao.ManageApplicant;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SignupApplicantController {
	/* ............... */
	int next = 0;
	int save = 0;
	int next1 = 0;
	/* ............... */
	@FXML
	private ImageView imagelogo;

	@FXML
	private ImageView imageanim;

	@FXML
	private JFXTextField textFirstNameApplicant;

	@FXML
	private JFXTextField textLastNameApplicant;

	@FXML
	private JFXDatePicker selectDateOfBirthApplicant;

	@FXML
	private JFXComboBox<?> selectGenderApplicant;

	@FXML
	private JFXTextField textEmailIdApplicant;

	@FXML
	private JFXPasswordField textPasswordApplicant;

	@FXML
	private JFXPasswordField textConfirmPasswordApplicant;

	@FXML
	private JFXButton buttonUploadResumeApplicant;

	@FXML
	private JFXTextField textLocationApplicant;

	@FXML
	private JFXTextField textPhoneApplicant;

	@FXML
	private JFXComboBox<?> selectemploymentStatusApplicant;

	@FXML
	private JFXTextField textSummaryApplicant;

	@FXML
	private JFXButton buttonNext1Applicant;

	@FXML
	private JFXButton buttonBack;

	@FXML
	private JFXButton buttonLogin;

	@FXML
	private ImageView imagelogo1;

	@FXML
	private ImageView imageanim1;

	@FXML
	private JFXTextField textUniversityApplicant;

	@FXML
	private JFXTextField textMajorApplicant;

	@FXML
	private JFXDatePicker selectMajorStartDateApplicant;

	@FXML
	private JFXDatePicker selectMajorEndDateApplicant;

	@FXML
	private JFXTextField textGPAApplicant;

	@FXML
	private JFXButton buttonNext2Applicant;

	@FXML
	private ImageView imagelogo2;

	@FXML
	private ImageView imageanim2;

	@FXML
	private VBox VBox;

	@FXML
	private JFXTextField textEmployerNameApplicant;

	@FXML
	private JFXTextField textDesignationApplicant;

	@FXML
	private JFXDatePicker selectExperienceStartDateApplicant;

	@FXML
	private JFXDatePicker selectExperienceEndDateApplicant;

	@FXML
	private JFXTextField textJobLocationApplicant;

	@FXML
	private JFXTextField textJobDescriptionApplicant;

	@FXML
	private JFXButton buttonDeleteExp;

	@FXML
    private JFXTextField cert_degree;

	@FXML
	private JFXButton buttonRegisterApplicant;

	@FXML
	private JFXButton buttonAddExp;

	@FXML
	void Back(ActionEvent event) throws IOException {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation");
		alert.setHeaderText("Sure! you want to continue");
		alert.setContentText("");

		Optional<ButtonType> result = alert.showAndWait();
	  	buttonBack.getScene().getWindow().hide();
		
			Stage signup = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/view/ChooseRole.fxml"));
			Scene scene = new Scene(root,700,600);
			signup.setScene(scene);
			signup.show();

	}

	@FXML
	void buttonAddExp(ActionEvent event) {
		save = 1;
		VBox.setVisible(true);
	}

	@FXML
	void buttonDeleteExp(ActionEvent event) {
		save = 2;
		VBox.setVisible(false);
	}

	@FXML
	void buttonNext1(ActionEvent event) {
		/* Validation of Personal details, Applicant */
		if (textFirstNameApplicant.getText() != null && textFirstNameApplicant.getText().isEmpty()
				|| !(textFirstNameApplicant.getText().matches("\\D+"))) {
			System.out.println("0");
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid First Name");
			alert.setHeaderText("Set valid first name");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textLastNameApplicant.getText() != null && textLastNameApplicant.getText().isEmpty()
				|| !(textLastNameApplicant.getText().matches("\\D+"))) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Last Name");
			alert.setHeaderText("Set valid last name");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
			String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
		} else if (selectDateOfBirthApplicant.getValue() == null) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Date");
			alert.setHeaderText("Set valid date");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (selectGenderApplicant.getValue() == null) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Gender");
			alert.setHeaderText("Set valid gender");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textEmailIdApplicant.getText() != null && textEmailIdApplicant.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Email Id");
			alert.setHeaderText("Set valid Email Id");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textPasswordApplicant.getText() != null && textPasswordApplicant.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Password");
			alert.setHeaderText("Set valid Password");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textConfirmPasswordApplicant.getText() != null && textConfirmPasswordApplicant.getText().isEmpty()
				|| !(textConfirmPasswordApplicant.getText().contentEquals(textPasswordApplicant.getText()))) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Password");
			alert.setHeaderText("Password did not match");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textLocationApplicant.getText() != null && textLocationApplicant.getText().isEmpty()
				|| !(textLocationApplicant.getText().matches("\\D+"))) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Location");
			alert.setHeaderText("Set valid location");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textPhoneApplicant.getText() != null && textPhoneApplicant.getText().isEmpty()
				|| !(textPhoneApplicant.getText().matches("\\d+")) || !(textPhoneApplicant.getLength() == 10)) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Phone no.");
			alert.setHeaderText("Set valid phone no.");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (selectemploymentStatusApplicant.getValue() == null) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Emplyment Status");
			alert.setHeaderText("Set valid emplyment status");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else {
			System.out.println("1");
			next1 = 1;
		}
		/*---------------------------------------------------------------------------*/

	}

	@FXML
	void buttonNext2(ActionEvent event) {
		/* Validation of Education Details */
		if (textUniversityApplicant.getText() != null && textUniversityApplicant.getText().isEmpty()
				|| !(textUniversityApplicant.getText().matches("\\D+"))) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid University Name");
			alert.setHeaderText("Set valid university  name");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textMajorApplicant.getText() != null && textMajorApplicant.getText().isEmpty()
				|| !(textMajorApplicant.getText().matches("\\D+"))) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Major");
			alert.setHeaderText("Set valid major");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (selectMajorStartDateApplicant.getValue() == null) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Major Start Date");
			alert.setHeaderText("Set valid major start date ");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (selectMajorEndDateApplicant.getValue() == null
				|| selectMajorEndDateApplicant.getValue().isBefore(selectMajorStartDateApplicant.getValue())) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid End Date");
			alert.setHeaderText("Set valid end date");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
			double a=Double.parseDouble(textGPAApplicant.getText());
			System.out.println(a);
		} else if (textGPAApplicant.getText() != null && textGPAApplicant.getText().isEmpty()
				|| (textGPAApplicant.getText().matches("\\D+")) || (Double.parseDouble(textGPAApplicant.getText()) > 4)
				|| (Double.parseDouble(textGPAApplicant.getText()) < 1)) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid GPA ");
			alert.setHeaderText("Set valid GPA ");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		}else if (cert_degree.getText() != null && cert_degree.getText().isEmpty()
				|| !(cert_degree.getText().matches("\\D+")) ) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Degree ");
			alert.setHeaderText("Set valid degree ");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else
			next = 2;

		/*-----------------------------------------------------------*/

	}

	@FXML
	void Register(ActionEvent event) {
		if (save == 1 && next == 2) {
			/* Validation Of Experience Details */
			if (textEmployerNameApplicant.getText() != null && textEmployerNameApplicant.getText().isEmpty()
					|| !(textEmployerNameApplicant.getText().matches("\\D+"))) {
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Invalid EmployerName");
				alert.setHeaderText("Set valid employer name");
				alert.setContentText("");

				Optional<ButtonType> result = alert.showAndWait();
			} else if (textDesignationApplicant.getText() != null && textDesignationApplicant.getText().isEmpty()
					|| !(textDesignationApplicant.getText().matches("\\D+"))) {
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Invalid Job Designation");
				alert.setHeaderText("Set valid designation");
				alert.setContentText("");

				Optional<ButtonType> result = alert.showAndWait();
			} else if (selectExperienceStartDateApplicant.getValue() == null) {
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Invalid Experience Start Date");
				alert.setHeaderText("Set valid experience start date");
				alert.setContentText("");

				Optional<ButtonType> result = alert.showAndWait();
			} else if (selectExperienceEndDateApplicant.getValue() == null || selectExperienceEndDateApplicant
					.getValue().isBefore(selectExperienceStartDateApplicant.getValue())) {
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Invalid experience end date");
				alert.setHeaderText("Set valid experience end date");
				alert.setContentText("");

				Optional<ButtonType> result = alert.showAndWait();
			} else if (textJobLocationApplicant.getText() != null && textJobLocationApplicant.getText().isEmpty()
					|| !(textJobLocationApplicant.getText().matches("\\D+"))) {
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Invalid Location");
				alert.setHeaderText("Set valid location");
				alert.setContentText("");

				Optional<ButtonType> result = alert.showAndWait();

			} else if (textJobDescriptionApplicant.getText() != null && textJobDescriptionApplicant.getText().isEmpty()
					|| !(textJobDescriptionApplicant.getText().matches("\\D+"))) {
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Invalid Job Description");
				alert.setHeaderText("Set valid job description");
				alert.setContentText("");

				Optional<ButtonType> result = alert.showAndWait();

			}

			else {
				RegisterApplicantDev();
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Done");
				alert.setHeaderText("Registered Successfully 1");
				alert.setContentText("");

				Optional<ButtonType> result = alert.showAndWait();

			}
			/*-------------------------------------------------------*/
		} else if (next == 2 && next1==1) {
			RegisterApplicantDev();
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Done");
			alert.setHeaderText("Registered Successfully");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();

		} else if (save == 2 && next == 2 && next1==1) {
			System.out.println("calling insert applicant");
			RegisterApplicantDev();
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Done");
			alert.setHeaderText("Registration Successful");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();

		} else if (save == 2 && !(next == 2)) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Error");
			alert.setHeaderText("Previous details are not Saved");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();

		}else if (save == 2 && !(next1 == 1)) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Error");
			alert.setHeaderText("Previous details are not Saved");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();

		} else {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Error");
			alert.setHeaderText("No Data Saved");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();

		}
	}

	@FXML
	void buttonUploadResume(ActionEvent event) {

	}

	@FXML
	void login(ActionEvent event) throws IOException {
		buttonLogin.getScene().getWindow().hide();

		Stage login = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
		Scene scene = new Scene(root, 520, 750);
		login.setScene(scene);
		login.show();
	}

	@FXML
	void selectEmploymentStatus(ActionEvent event) {

	}

	@FXML
	void selectGenderApplicant(ActionEvent event) {

	}

	@FXML
	 public void RegisterApplicantDev(){
	    	
	    	System.out.println("inside regDev");
	    
	    	//Users - 
	    	//applicant_profile
	    	//applicant_edu
	    	//applicant_exp
	    	System.out.println("Email Id"+textEmailIdApplicant.getText()+"Password = "+textPasswordApplicant.getText());
	    	char status =  ManageApplicant.registerApplicantDev(
	    			
	    			textEmailIdApplicant.getText(),textPasswordApplicant.getText(),
	    			
	    			textFirstNameApplicant.getText(), textLastNameApplicant.getText(),textPhoneApplicant.getText(),
	    			textLocationApplicant.getText(),textSummaryApplicant.getText()	,selectemploymentStatusApplicant.getValue().toString(),
	    			selectDateOfBirthApplicant.getValue(),selectGenderApplicant.getValue().toString(),
	    			
	    			textUniversityApplicant.getText(), textMajorApplicant.getText(), selectMajorStartDateApplicant.getValue(),
	    			selectMajorEndDateApplicant.getValue(), textGPAApplicant.getText(),
	    			
	    			textEmployerNameApplicant.getText(), textDesignationApplicant.getText(), selectExperienceStartDateApplicant.getValue(),
	    			selectExperienceEndDateApplicant.getValue(), textJobLocationApplicant.getText(), textJobDescriptionApplicant.getText()		
	    			);
	   
	    	if(status=='s')
	    	{
	    		Alert alert1 = new Alert(AlertType.INFORMATION);
				alert1.setTitle("Success");
				alert1.setHeaderText("Profile created");
				alert1.showAndWait();
	    		
	    	}
	    	else if(status=='e')
	    	{
	    		Alert alert1 = new Alert(AlertType.INFORMATION);
			alert1.setTitle("Error");
			alert1.setHeaderText("User with this email already exists");
			alert1.showAndWait();
	    	}
	    	else if(status=='f')
	    	{
	    	Alert alert1 = new Alert(AlertType.INFORMATION);
			alert1.setTitle("Error");
			alert1.setHeaderText("Profile could not be created");
			alert1.showAndWait();
	    	}

	}
}
