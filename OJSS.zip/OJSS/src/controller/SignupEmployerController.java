package controller;

import java.io.IOException;
import java.util.Optional;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import dao.Connector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class SignupEmployerController {

    @FXML
    private ImageView imageanim;

    @FXML
    private JFXTextField textCompanyName;

    @FXML
    private ImageView imagelogo;

    @FXML
    private JFXPasswordField textPassword2;

    @FXML
    private DatePicker establishmentDate;

    @FXML
    private JFXPasswordField textPassword1;

    @FXML
    private JFXTextField textLocation;

    @FXML
    private JFXTextField textIndustry;
    @FXML
    private JFXTextField textCompanyURL;
    @FXML
    private JFXTextField textPhoneNo;
    @FXML
    private JFXTextField textEmailId;
    @FXML
    private JFXTextField textDescription;
    @FXML
    private JFXButton buttonUploadLogo;

    @FXML
    private JFXButton buttonRegister;
    
    @FXML
    private Label labelStatus;
    
    @FXML
    private JFXButton buttonLogin;

    @FXML
    private JFXButton buttonBack;
    
    @FXML
    public void Register(){
		if (textCompanyName.getText() != null && textCompanyName.getText().isEmpty()) {
			System.out.println("0");
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Company Name");
			alert.setHeaderText("Set a valid company name");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textEmailId.getText() != null && textEmailId.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Email ID");
			alert.setHeaderText("Set a valid Email Id");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textPassword1.getText() != null && textPassword1.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Password");
			alert.setHeaderText("Set A valid Password");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textPassword2.getText() != null && textPassword2.getText().isEmpty()
				|| !(textPassword2.getText().contentEquals(textPassword1.getText()))) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Password");
			alert.setHeaderText("Password didn't match");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textLocation.getText() != null && textLocation.getText().isEmpty()
				|| textLocation.getText().matches("\\d+")) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Location");
			alert.setHeaderText("Set a valid location");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textIndustry.getText() != null && textIndustry.getText().isEmpty()
				|| textIndustry.getText().matches("\\d+")) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Industry");
			alert.setHeaderText("Set a valid industry name");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (establishmentDate.getValue() == null) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Establishment Date");
			alert.setHeaderText("Select a valid Date");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textCompanyURL.getText() != null && textCompanyURL.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Invalid Company URL");
			alert.setHeaderText("Set a valid URL");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textPhoneNo.getText() != null && textPhoneNo.getText().isEmpty()
				|| !(textPhoneNo.getText().matches("\\d+")) || !(textPhoneNo.getLength()==10) ) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("invalid Phone No.");
			alert.setHeaderText("Set a valid phone no.");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else if (textDescription.getText() != null && textDescription.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Inavild Job Description");
			alert.setHeaderText("Set a valid job description");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
		} else {
			System.out.println("inside register");
			int i = Connector.registerEmployer(textEmailId.getText(), textPassword1.getText(),
					textCompanyName.getText(), textIndustry.getText(), textLocation.getText(),
					establishmentDate.getValue().toString(), textCompanyURL.getText(), textPhoneNo.getText(),
					textDescription.getText());

			// int i = Connector.registerEmployer1(textEmailId.getText(),
			// textPassword1.getText(), textCompanyName.getText());
			if (i == 0) {
				labelStatus.setText("Registration Successfull");

			} else
				labelStatus.setText("Registration failed");
		}
	}
    public void login(ActionEvent event) throws IOException {
    	
    	buttonLogin.getScene().getWindow().hide();
		
		Stage login = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
		Scene scene = new Scene(root,520,750);
		login.setScene(scene);
		login.show();
    }
    
    public void uploadLogo(){}

    // Moulik Validation
    
    @FXML
    void Back(ActionEvent event) throws IOException {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Sure! You want to Continue");
		alert.setContentText("");

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK) {

			buttonBack.getScene().getWindow().hide();

			Stage signup = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/view/ChooseRole.fxml"));
			Scene scene = new Scene(root, 700, 600);
			signup.setScene(scene);
			signup.show();
		}
    }    

}
