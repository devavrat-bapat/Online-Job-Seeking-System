package controller;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXTextField;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import model.Applicant;

public class ProfileApplicantController extends HomepageApplicantController implements Initializable{
	
	@FXML
	AnchorPane paneProfileApplicant;
	
	@FXML
    private JFXTextField summary;

    @FXML
    private JFXTextField resume;

    @FXML
    private JFXTextField phone_no;

    @FXML
    private JFXTextField university;

    @FXML
    private JFXTextField edu_start_date;

    @FXML
    private JFXTextField cert_degree;

    @FXML
    private ImageView profile_pic;

    @FXML
    private JFXTextField emp_name;

    @FXML
    private JFXTextField last_name;

    @FXML
    private JFXTextField edu_end_date;

    @FXML
    private JFXTextField major;

    @FXML
    private JFXTextField job_start_date;

    @FXML
    private JFXTextField job_description;

    @FXML
    private JFXTextField user_id;

    @FXML
    private JFXTextField curr_sal;

    @FXML
    private JFXTextField job_end_date;

    @FXML
    private JFXTextField gpa;

    @FXML
    private JFXTextField location;

    @FXML
    private JFXTextField designation;

    @FXML
    private JFXTextField first_name;

    @FXML
    private JFXTextField job_location;
   
    String f="Dev",l="Bapat";
    @Override
	public void initialize(URL location, ResourceBundle resources) {
	
    	first_name.setText(a1.first_name);
    	last_name.setText(a1.last_name);
    	
	}
    ProfileApplicantController(Applicant a2) {
		super(a2);
		
	}
    
    
}
