package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Admin;
import model.Applicant;
import model.Employer;
import model.User;
import dao.Connector;

import java.util.ResourceBundle;
import com.jfoenix.controls.*;


public class LoginController implements Initializable{

	
	@FXML
	private TextField textFieldUsername;
	
	@FXML
	private TextField passwordFieldPassword;
	
	@FXML
	private AnchorPane anchorPaneLogin;
	
	@FXML
	private Label labelLoginStatus;
	@FXML
	private Button buttonLogin;

    @FXML
    private JFXButton buttonSignup;

    @FXML
    private JFXButton buttonlogin;

    @FXML
    private ImageView imageanim;

    @FXML
    private JFXButton buttonforgot;

    @FXML
    private ImageView imagelogo;

    @FXML
    private ImageView imagelogopassword;

    @FXML
    private JFXCheckBox checkboxRemember;

    @FXML
    private ImageView imagelogouser;
   
    public String currole;
    public int curuserID;
		
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
	}
	// check the user
	@FXML
	public void Login(ActionEvent event) throws IOException, SQLException {
		
		Date dt = new Date();

		java.text.SimpleDateFormat sdf = 
		     new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String currentTime = sdf.format(dt);
		
			System.out.println("time now :"+currentTime);
			User u1 = new User();
			u1.password = passwordFieldPassword.getText();
			u1.username = textFieldUsername.getText();
			Connector.validateLogin(u1);
			System.out.println("login called "+u1.password+u1.userID+u1.username+u1.role);
			
		switch(u1.role)
		{
		case "admin":
			Connector.insertLog(u1.userID,currentTime);			
			Admin admin = new Admin(u1.userID);
			//admin = Connector.getApplicant(a1);
			System.out.println("got admin profile");	
			buttonlogin.getScene().getWindow().hide();
			System.out.println("reached here 1");
			Stage adminProfile = new Stage();
			
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/homeAdmin.fxml"));

			//ProfileApplicantController p1 = new ProfileApplicantController(a1);
		//	HomepageApplicantController hp1 = new HomepageApplicantController(a1);
			
		//	fxmlLoader.setController(hp1);
			
			Parent root1 = (Parent)fxmlLoader.load(); 
			
			Scene scene1 = new Scene(root1,700,600);
			adminProfile.setScene(scene1);
			adminProfile.show();
			break;

		case "applicant":
			Connector.insertLog(u1.userID,currentTime);			
			Applicant a1 = new Applicant(u1.userID);
			a1 = Connector.getApplicant(a1);
			System.out.println("got applicant profile");	
			buttonlogin.getScene().getWindow().hide();
			System.out.println("reached here 1");
			Stage applicantProfile = new Stage();
			
			FXMLLoader fxmlLoader2 = new FXMLLoader(getClass().getResource("/view/HomepageApplicant.fxml"));

			//ProfileApplicantController p1 = new ProfileApplicantController(a1);
			HomepageApplicantController hp1 = new HomepageApplicantController(a1);
			
			fxmlLoader2.setController(hp1);
			
			Parent root2 = (Parent)fxmlLoader2.load(); 
			
			Scene scene2 = new Scene(root2,700,600);
			applicantProfile.setScene(scene2);
			applicantProfile.show();
			break;

		case "employer":
			Connector.insertLog(u1.userID,currentTime);			
			Employer e1 = new Employer(u1.userID);
			e1 = Connector.getEmployer(e1);
			System.out.println("got employer profile");	//working till now
			buttonlogin.getScene().getWindow().hide();
			
			Stage employerProfile = new Stage();
			
			FXMLLoader fxmlLoader3 = new FXMLLoader(getClass().getResource("/view/HomepageEmployer.fxml"));
					
			//ProfileEmployerController p3 = new ProfileEmployerController(e1);
			HomepageEmployerController he1 = new HomepageEmployerController(e1);
			
			System.out.println("err1");
			fxmlLoader3.setController(he1);
			System.out.println("err2");
			Parent root3 = (Parent)fxmlLoader3.load();
			System.out.println("err3");
			Scene scene3 = new Scene(root3,700,600);
			employerProfile.setScene(scene3);
			employerProfile.show();
			break;

		case "invalid":
			labelLoginStatus.setText("Incorrect username/password");
			labelLoginStatus.setTextFill(Color.web("red"));
			break;
		
		}		

	}

	
	// get the user profile from database
	
	/*select * from applicant where user_id = 
	
		Applicant app = new Applicant(rs.getInt(1));
		app = getApplicantProfile();
	
	// call the homepage
	// initialize the controller
	
	private static Applicant getApplicantProfile(user_id) throws SQLException {
		// TODO Auto-generated method stub
	
		return app;
	}*/
	
	
	
	
public void Signup(ActionEvent event) throws IOException{
		
		
		buttonlogin.getScene().getWindow().hide();
		
		Stage signup = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/view/ChooseRole.fxml"));
		Scene scene = new Scene(root,700,600);
		signup.setScene(scene);
		signup.show();
		
		/*Stage primaryStage= new Stage();
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/ChooseRole.fxml"));
        AnchorPane root;
		try {
			root = (AnchorPane) loader.load();
			Scene scene = new Scene(root,400,400);
//			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			Stage stage = (Stage) buttonLogin.getScene().getWindow();
			stage.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		*/
	}
}
