package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.function.Function;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;

import dao.ApplyForJob;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import model.Applicant;
import model.Employer;
import model.JobPost;



public class HomepageApplicantController implements Initializable{
	  	
	  	
	    @FXML
	    private TableColumn<?, ?> columnUserid;
	    @FXML
	    private TableColumn<?, ?> columnUserId2;

	    @FXML
	    private TableColumn<?, ?> columnEmpName;
	    @FXML
	    private ImageView imageanim;

	    @FXML
	    private MenuButton menuButtonJobType;
	    
	    @FXML
	    private TableColumn<?, ?> columnLocation;

	    @FXML
	    private TableColumn<?, ?> columnIsactive;

	    @FXML
	    private TableColumn<?, ?> columnExpirydate;

	    @FXML
	    private Tab tableViewEmployer;

	    @FXML
	    private TableColumn<?, ?> columnDesignation;

	    @FXML
	    private TableView<JobPost> tableJobPost;
	    
	    @FXML
	    private TableColumn<JobPost, Boolean> colEdit;
	    
	    @FXML
	    private TableView<Employer> tableviewEmployer;

	    @FXML
	    private TableColumn<?, ?> columnJobtype;

	    @FXML
	    private ImageView imagelogo;

	    @FXML
	    private TableColumn<?, ?> columnJobid;

	    @FXML
	    private TableColumn<?, ?> columnDescription;
	    @FXML
	    private TableColumn<?, ?> columnCreatedate;
	    @FXML
	    private TableColumn<?, ?> columnCompanyName;
	    @FXML
	    private TableColumn<? ,?> columnAction1;
	    @FXML
	    private TableColumn<?, ?> columnEmailId;
	    @FXML
	    private TableColumn<?, ?> columnIndustryType;
	    @FXML
	    private TableColumn<?, ?> columnLocation1;
	    @FXML
	    private TableColumn<?, ?> columnEstablishmentDate;
	    @FXML
	    private TableColumn<?, ?> columnCompanyUrl;
	    @FXML
	    private TableColumn<?, ?> columnPhoneNo;
	    @FXML
	    private TableColumn<?, ?> columnDescription1;
	    
	    @FXML
	    private JFXTextField last_name;
	    @FXML
	    private JFXTextField first_name;
	    @FXML
	    private JFXDatePicker date_of_birth;

	    @FXML
	    private JFXTextField gender;

	    @FXML
	    private JFXTextField email_id;

	    @FXML
	    private JFXTextField location;

	    @FXML
	    private JFXTextField phone;

	    @FXML
	    private JFXTextField employment_status;

	    @FXML
	    private JFXTextField university;

	    @FXML
	    private JFXTextField major;

	    @FXML
	    private JFXTextField start_date;

	    @FXML
	    private JFXTextField end_date;

	    @FXML
	    private JFXTextField gpa;

	    @FXML
	    private JFXTextField employer_name;

	    @FXML
	    private JFXTextField designation;

	    @FXML
	    private JFXTextField job_location;

	    @FXML
	    private JFXTextField job_description;

	    @FXML
	    private JFXButton buttonEditProfile;

	    
	    @FXML
	    private JFXButton buttonLogout;
	    @FXML
	    private JFXComboBox<?> combo;
	    @FXML
	    private JFXComboBox<?> combo1;
	    @FXML
	    private JFXComboBox<?> combo2;
	    @FXML
	    private JFXComboBox<?> combo3;
	    @FXML
	    private JFXComboBox<?> combo4;
	    @FXML
	    private JFXComboBox<?> combo5;
	   
	    @FXML
	    private JFXComboBox<?> combo6;
	    @FXML
	    private JFXComboBox<?> combo7;
	    @FXML
	    private JFXComboBox<?> combo8;
	    @FXML
	    private JFXComboBox<?> combo9;
	    @FXML
	    private JFXComboBox<?> combo10;
	    
	    
	    
	  	Applicant a1;
	  	ObservableList<JobPost> ol;
	  	ObservableList<Employer> ol2;
	  	JobPost jb1;
	  	JobPost jb2;
	  	Employer emp1;
	  	
	  	HomepageApplicantController(Applicant a2){
	  		a1 = a2;
	  		this.a1.user_id = a2.user_id;
	  		this.a1.first_name = a2.first_name;
	  		this.a1.last_name = a2.last_name;
	  		System.out.println("hp constr");
	  		System.out.println("reached here 2");
	  	}
	  	 
		@Override
		public void initialize(URL location, ResourceBundle resources) {
			
			
			displayProfile();
			
			
			setCellTable();
			System.out.println("here 10");
			setEmployerTable();
			System.out.println("here 11");
			try {
				
				System.out.println("here 12");
				loadDataintoTable();
				loadDataintoViewEmployer2();
			} catch (SQLException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			combo.getSelectionModel().selectFirst();
			combo1.getSelectionModel().selectFirst();
			combo2.getSelectionModel().selectFirst();
			combo3.getSelectionModel().selectFirst();
			combo7.getSelectionModel().selectFirst();
			combo8.getSelectionModel().selectFirst();
			combo9.getSelectionModel().selectFirst();
			
		}			
		private void displayProfile() {
			first_name.setText(a1.first_name);
			last_name.setText(a1.last_name);
			System.out.println("reacehed here 3");
			phone.setText(a1.phone_no.toString());
			gender.setText(a1.gender);
			email_id.setText(a1.email_id);
			location.setText(a1.location);
			employment_status.setText(a1.employment_status);
			university.setText(a1.university);
			major.setText(a1.major);
			
			
			
		}
		@FXML
		public void editProfile()
		{
			
		}

		public void setCellTable(){
			
			
			columnJobid.setCellValueFactory(new PropertyValueFactory<>("job_id"));    
			columnEmpName.setCellValueFactory(new PropertyValueFactory<>("company_name"));
			columnJobtype.setCellValueFactory(new PropertyValueFactory<>("jobType"));
			columnDesignation.setCellValueFactory(new PropertyValueFactory<>("designation"));
			columnDescription.setCellValueFactory(new PropertyValueFactory<>("jobDesctiption"));
			columnLocation.setCellValueFactory(new PropertyValueFactory<>("location"));
			columnCreatedate.setCellValueFactory(new PropertyValueFactory<>("createdDate"));
			columnExpirydate.setCellValueFactory(new PropertyValueFactory<>("expiredDate"));
		//	columnAction1.setCellValueFactory(new PropertyValueFactory<>("btn1"));	
			colEdit.setCellFactory(cellFactory);
			
		}
		
		
		
		Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>> cellFactory = 
				new Callback<TableColumn<JobPost, Boolean>, TableCell<JobPost, Boolean>>()
		{
			@Override
			public TableCell<JobPost, Boolean> call( final TableColumn<JobPost, Boolean> param)
			{
				final TableCell<JobPost, Boolean> cell = new TableCell<JobPost, Boolean>()
				{
					Image imgEdit = new Image(getClass().getResourceAsStream("/imagetemp/edit.png"));
					final Button btnEdit = new Button();
					
					@Override
					public void updateItem(Boolean check, boolean empty)
					{
						super.updateItem(check, empty);
						if(empty)
						{
							setGraphic(null);
							setText(null);
						}
						else{
							btnEdit.setOnAction(e ->{
								JobPost user = getTableView().getItems().get(getIndex());
								updateUser(user);
							});
							
							btnEdit.setStyle("-fx-background-color: transparent;");
							ImageView iv = new ImageView();
					        iv.setImage(imgEdit);
					        iv.setPreserveRatio(true);
					        iv.setSmooth(true);
					        iv.setCache(true);
							btnEdit.setGraphic(iv);
							
							setGraphic(btnEdit);
							setAlignment(Pos.CENTER);
							setText(null);
						}
					}

					private void updateUser(JobPost user) {
						//.setText(Long.toString(user.getId()));
						System.out.println("Job id ="+user.jobId);
						int flag = ApplyForJob.apply(a1.user_id, user.jobId);
						Alert alert = new Alert(AlertType.CONFIRMATION);
						if(flag==0)
						{
						alert.setTitle("Application Status");
						alert.setHeaderText("Successfully Applied");
						alert.setContentText("");
						}
						else
						{
							alert.setTitle("Application Status");
							alert.setHeaderText("Cannot Apply");
							alert.setContentText("");
							
						}
						alert.showAndWait();
					}
				};
				return cell;
			}
		};

		
		public EventHandler<ActionEvent> alterMsg(){
			
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Sure! You want to Continue");
			alert.setContentText("");
			return null;
		
		}
		
		private void loadDataintoTable() throws SQLException {
			jb1 = new JobPost();
			ResultSet rs = jb1.getJobPost();
			ol = FXCollections.observableArrayList();
			int i=1;
			while(rs.next()){
				System.out.println("job post row "+i);
				i++;
				ol.add(new JobPost(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),""+rs.getObject(7),""+rs.getObject(8)));
			}
			tableJobPost.setItems(ol);	
			
		}
          
		
		
		public void applyFilters() throws SQLException{
			
			System.out.println("reached here 4");
			setCellTable();
			jb2 = new JobPost();	
			ResultSet rs = jb2.applyManyFilters(combo.getValue().toString(),combo1.getValue().toString(),combo2.getValue().toString(),combo3.getValue().toString());
			ol = FXCollections.observableArrayList();
			int i=1;
			while(rs.next()){
			//	System.out.println("job post row "+i);
				i++;
				System.out.println(""+rs.getInt(1)+""+rs.getString(2)+""+rs.getString(3)+""+rs.getString(4)+""+rs.getString(5)+""+rs.getString(6)+""+rs.getObject(7)+""+rs.getObject(8)+""+rs.getString(9));
				ol.add(new JobPost(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),""+rs.getObject(7),""+rs.getObject(8)));
			}
			tableJobPost.setItems(ol);	
		}
		public void applyFiltersEmployer() throws SQLException, ParseException{
			
			System.out.println("reached here 777777777");
			setEmployerTable();
			emp1 = new Employer();	
			ResultSet rs1 = emp1.applyManyFiltersEmp(combo7.getValue().toString(),combo8.getValue().toString(),combo9.getValue().toString());
			ol2 = FXCollections.observableArrayList();
			int i=1;
			while(rs1.next()){
				System.out.println("emp row "+i);
				i++;
				System.out.println(""+rs1.getDate(6));
				ol2.add(new Employer(rs1.getInt(1),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getDate(6),rs1.getString(7),rs1.getString(8),rs1.getString(9)));
			}
			tableviewEmployer.setItems(ol2);	
		}

		
		public void setEmployerTable(){
			System.out.println("13");
			columnUserId2.setCellValueFactory(new PropertyValueFactory<>("user_id"));
			columnCompanyName.setCellValueFactory(new PropertyValueFactory<>("company_name"));
			columnEmailId.setCellValueFactory(new PropertyValueFactory<>("email_id"));
			columnIndustryType.setCellValueFactory(new PropertyValueFactory<>("industry_type"));
			columnLocation1.setCellValueFactory(new PropertyValueFactory<>("location"));
			columnEstablishmentDate.setCellValueFactory(new PropertyValueFactory<>("establishment_date"));
			columnCompanyUrl.setCellValueFactory(new PropertyValueFactory<>("company_url"));
			columnPhoneNo.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
			columnDescription1.setCellValueFactory(new PropertyValueFactory<>("description"));
		}
		
		private void loadDataintoViewEmployer() throws SQLException {

			emp1 = new Employer();
			ResultSet rs1 = emp1.getEmployer();
			ol2 = FXCollections.observableArrayList();
			int i=1;
			while(rs1.next()){
				System.out.println("emp row "+i);
				i++;
		//		ol2.add(new Employer(rs1.getInt(1),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getDate(6),rs1.getString(7),rs1.getDouble(8),rs1.getString(9)));
			}
			tableviewEmployer.setItems(ol2);	
		}
		private void loadDataintoViewEmployer2() throws SQLException, ParseException {

			emp1 = new Employer();
			ResultSet rs1 = emp1.getEmployer2();
			ol2 = FXCollections.observableArrayList();
			int i=1;
			while(rs1.next()){
				System.out.println("emp row "+i);
				i++;
				ol2.add(new Employer(rs1.getInt(1),rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5),rs1.getDate(6),rs1.getString(7),rs1.getString(8),rs1.getString(9)));
			}
			tableviewEmployer.setItems(ol2);	
		}
		
		@FXML
		void logout(ActionEvent event) throws IOException {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Sure! You want to Logout");
			alert.setContentText("");

			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK) {

				buttonLogout.getScene().getWindow().hide();

				Stage signup = new Stage();
				Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
				Scene scene = new Scene(root, 700, 600);
				signup.setScene(scene);
				signup.show();
			}
		}
		
		@FXML
	    void editProfile(ActionEvent event) {
	    	
	    }
}











