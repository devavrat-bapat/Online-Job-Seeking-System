package controller;

import java.io.IOException;
import java.util.Optional;

import com.jfoenix.controls.JFXButton;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ChooseRoleController {

    @FXML
    private JFXButton buttonApplicantSignup;

    @FXML
    private ImageView imageEmployerSignup;

    @FXML
    private ImageView imageApplicantSIgnup;

    @FXML
    private JFXButton buttonEmployerSignup;

    @FXML
    private JFXButton buttonBack;


    @FXML
    void SignupApplicant(ActionEvent event) throws IOException {
    	buttonApplicantSignup.getScene().getWindow().hide();
		
		Stage signup = new Stage();
		
		// set role = applicant
		// display the form, collect data from one form and store it into object of Applicant
		
		
		Parent root = FXMLLoader.load(getClass().getResource("/view/SignupApplicant.fxml"));
		Scene scene = new Scene(root,1100,750);
		signup.setScene(scene);
		signup.show();
    }

    @FXML
    void SignupEmployer(ActionEvent event) throws IOException {
    	buttonEmployerSignup.getScene().getWindow().hide();
		
		Stage signup = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/view/SignupEmployer.fxml"));
		Scene scene = new Scene(root,1100,750);
		signup.setScene(scene);
		signup.show();
    }

    @FXML
    void back(ActionEvent event) throws IOException {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation");
		alert.setHeaderText("Sure! you want to continue");
		alert.setContentText("");

		Optional<ButtonType> result = alert.showAndWait();
	  	buttonBack.getScene().getWindow().hide();
		
			Stage signup = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
			Scene scene = new Scene(root,700,600);
			signup.setScene(scene);
			signup.show();
	  
    }
}
